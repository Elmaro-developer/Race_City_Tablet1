# Maro City Tablet RP

Forge mod for **Minecraft Java 1.21.11** (Forge **61.2.4**, Java 21, mod id `marocitytablet`) that adds two tablets
for roleplay servers: an **Owner Tablet** (city management) and a **Player Tablet** (citizen profile, wallet, RP data).

> **Build status — read this first.** This project was written in an environment that could not reach Forge's
> Maven, Mojang's servers or the Gradle plugin portal, so **`gradle build` and the Client / Dedicated Server runs were
> NOT executed** and **no JAR is included**. What *was* verified is listed in "Verification" below. Expect that the
> first real build may need small fixes for Minecraft API details that could not be compiled here.

## Build and run

Requirements: JDK 21, Gradle 9.x (Forge 1.21.11 itself uses Gradle 9.5.0), internet access.

```bash
gradle wrapper --gradle-version 9.5.0     # once; creates ./gradlew
./gradlew build                           # jar in build/libs/marocitytablet-1.0.0.jar
./gradlew runClient                       # test on a client (single player)
./gradlew runServer                       # test on a dedicated server (accept the EULA in run/eula.txt)
```

Install the jar in the `mods/` folder of **both** the server and every client (same Forge 61.x).

## Set up the owner

The primary owner is identified by **UUID in a server-side file**, never by anything the client sends.
On first start the server writes `config/marocitytablet-server.json`:

```json
{ "ownerUuids": ["xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"], "cityName": "Maro City", "currencySymbol": "$", ... }
```

Put your UUID in `ownerUuids` (dashes optional), restart (or run `/marocity reload`), then run `/marocity give owner`.
In single player you can run `/marocity claimowner` instead (refused on dedicated servers).
Owner UUIDs are never sent to clients and cannot be edited from the tablet.

## Features

| Area | What it does |
|---|---|
| Owner Tablet | Dashboard, player list + search, player profiles, staff add/remove, per-permission grant/revoke, job/rank/level editing, balance editing, city statistics, admin audit log, server settings |
| Player Tablet | Profile (name, avatar initial, job, rank, level, balance, play time, kills/deaths/advancements), wallet with transfers and history, editable RP data, job/rank/level history |
| Permissions | `VIEW_PLAYERS, VIEW_STATS, EDIT_JOBS, EDIT_RANKS, MANAGE_STAFF, EDIT_BALANCE, VIEW_LOGS, SERVER_MANAGEMENT`, each separate |
| Economy | Per-player balance, admin add/remove/set, player transfers, ledger, no negative balances, configurable maximum |
| Storage | JSON in `<world>/marocitytablet/` (`players.json`, `transactions.json`, `adminlog.json`) + `config/marocitytablet-server.json`; atomic writes, saved every 30 s, on logout and on server stop; a corrupt file is moved aside (`*.corrupt-<time>`), never overwritten |
| Languages | English and Arabic (`en_us`, `ar_sa`) |

Commands (all authorised through the mod's own permission system, **not** vanilla OP level):
`/balance`, `/pay <player> <amount>`, `/marocity tablet`, `/marocity give owner`,
`/marocity give player <name>`, `/marocity claimowner` (single player), `/marocity reload`.

## Security model

* The client only sends *intent* (`ActionPacket`: action + arguments). Every action is re-checked on the server in
  `admin/ActionService` against server-side data. The tab list on the client is cosmetic.
* Right-clicking an Owner Tablet sends nothing unless the server confirms the user is the owner or staff.
  Possessing the item grants nothing.
* The owner cannot be modified by anyone else. Staff can only grant/revoke permissions they hold; `MANAGE_STAFF`
  and `SERVER_MANAGEMENT` can only be granted/revoked by the owner.
* All client strings are sanitised (control characters and `§` removed, length-limited); packet strings have hard
  length limits; requests are rate-limited (40 per second per player).
* Denied attempts are written to the audit log as `DENIED:<ACTION>`.
* The audit log and ledger keep the newest 50,000 entries each.

## Project layout

```
com.maro.marocitytablet
  main/        MaroCityTablet (entry), ServerEvents, TabletServer (glue), TabletCommands
  registry/    ModItems, ModCreativeTabs
  items/       TabletItem, TabletKind
  client/      ClientPacketHandler (client only)
  screens/     TabletScreen (frame), PlayerTabletScreen, OwnerTabletScreen, Ui (theme)
  networking/  ModNetwork (SimpleChannel), ActionPacket, ViewPacket, OpenTabletPacket, RateLimiter
  permissions/ Permission, PermissionManager
  players/     PlayerRecord, PlayerService
  economy/     EconomyService, Transaction
  storage/     DataStore, JsonStorage
  admin/       ActionService (server authority), ViewBuilder, TabletCore, ActionType, ...
  config/      ServerSettings, SettingsManager
```

`admin`, `permissions`, `players`, `economy`, `storage` and `config` do not depend on Minecraft, which is what makes
the logic testable without a game.

## Verification performed

| Check | Result |
|---|---|
| Core logic self test (`selftest/run.sh`, plain Java + Gson): permissions, escalation limits, owner protection, economy invariants, sanitising, persistence across restart, corrupt-file handling | **74 / 74 passed** |
| Translation keys used in code exist in `en_us` and `ar_sa` (`selftest/check_lang.py`) | passed |
| Screens + core type-checked with `javac` against hand-written stubs of the Minecraft GUI API | passed (stubs reflect the API as read from Forge's sources, so this only proves *my* code is self-consistent) |
| Forge API usage (event buses, `SimpleChannel`, `DeferredRegister`, `RegisterEvent`, creative tab, `Identifier`) | read against Forge `1.21.11` sources and its own test mods |
| `gradle build`, `runClient`, `runServer` | **not run** (network blocked) |
| Visual look of the GUI, in-game behaviour | **not seen** |

## Known limitations

* Not compiled against the real Minecraft/Forge jars. Vanilla calls that Forge's sources do not exercise
  (`MinecraftServer.getTickCount`, `PlayerList.getPlayerByName/getPlayerCount`, `Inventory.getContainerSize`,
  `Player.drop`, `Advancement.display()`, `Font.plainSubstrByWidth`) were written from memory of 1.21.x.
* The "player head" is a letter avatar, not the skin face (skin rendering APIs changed recently and could not be checked).
* Kills, deaths, play time and advancements are counted from the moment the mod is installed, not imported from vanilla stats.
* Standard vanilla buttons are used inside the dark/gold/red panels; no custom button textures.
* Textures are simple generated 16x16 icons.
* No Gradle wrapper jar is included.
* No data generators or JUnit tests in Gradle; the self test is a standalone Java program.
