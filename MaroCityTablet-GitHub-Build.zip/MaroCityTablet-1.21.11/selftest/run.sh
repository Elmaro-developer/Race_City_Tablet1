#!/usr/bin/env bash
# Compiles and runs the Minecraft-free core self test. Needs JDK 21 and a Gson jar.
# Usage: selftest/run.sh [path/to/gson.jar]
set -euo pipefail
cd "$(dirname "$0")/.."
GSON="${1:-${GSON_JAR:-}}"
if [ -z "$GSON" ]; then
  GSON="$(find "$HOME/.gradle" "$HOME/.m2" /opt -name 'gson-*.jar' 2>/dev/null | head -1 || true)"
fi
[ -f "$GSON" ] || { echo "Gson jar not found. Pass it as the first argument."; exit 2; }
OUT="$(mktemp -d)"
CORE=$(find src/main/java \( -path '*/admin/*' -o -path '*/config/*' -o -path '*/economy/*' -o -path '*/permissions/*' -o -path '*/players/*' -o -path '*/storage/*' \) -name '*.java')
javac -d "$OUT" -cp "$GSON" $CORE selftest/CoreSelfTest.java
java -cp "$OUT:$GSON" CoreSelfTest
