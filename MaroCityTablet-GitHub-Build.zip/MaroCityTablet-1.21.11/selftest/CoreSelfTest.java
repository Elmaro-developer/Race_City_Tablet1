import com.google.gson.JsonObject;
import com.maro.marocitytablet.admin.ActionService;
import com.maro.marocitytablet.admin.ActionType;
import com.maro.marocitytablet.admin.OnlineInfo;
import com.maro.marocitytablet.admin.TabletCore;
import com.maro.marocitytablet.economy.EconomyService;
import com.maro.marocitytablet.permissions.Permission;
import com.maro.marocitytablet.players.PlayerRecord;
import com.maro.marocitytablet.admin.OpResult;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Plain-Java self test for the server-side core (no Minecraft needed). Run with selftest/run.sh.
 * It exercises the same code paths the Forge packet handler calls.
 */
public final class CoreSelfTest {
    static int passed, failed;

    static void check(boolean cond, String what) {
        if (cond) {
            passed++;
            System.out.println("  PASS  " + what);
        } else {
            failed++;
            System.out.println("  FAIL  " + what);
        }
    }

    static final OnlineInfo ONLINE = new OnlineInfo() {
        public boolean isOnline(UUID u) { return true; }
        public int onlineCount() { return 3; }
    };

    static TabletCore boot(Path dir, AtomicLong clock) {
        TabletCore c = new TabletCore(dir.resolve("cfg.json"), dir.resolve("data"), clock::incrementAndGet, ONLINE);
        c.load();
        return c;
    }

    static String toastKey(ActionService.Response r) {
        for (ActionService.View v : r.views()) {
            if (v.name().equals("toast")) return v.data().get("key").getAsString();
        }
        return "<no toast>";
    }

    static boolean toastOk(ActionService.Response r) {
        for (ActionService.View v : r.views()) {
            if (v.name().equals("toast")) return v.data().get("ok").getAsBoolean();
        }
        return false;
    }

    static ActionService.Response act(TabletCore c, UUID who, String name, ActionType t, String target, String a, String b, long n) {
        return c.actions.handle(who, name, t, target, a, b, n);
    }

    public static void main(String[] args) throws Exception {
        Path dir = Files.createTempDirectory("maro-selftest");
        AtomicLong clock = new AtomicLong(1_000_000);
        TabletCore c = boot(dir, clock);

        UUID ownerId = UUID.randomUUID(), adminId = UUID.randomUUID(), bobId = UUID.randomUUID(), aliceId = UUID.randomUUID();
        c.settings.get().ownerUuids.add(ownerId.toString().toUpperCase().replace("-", "")); // dashes/case must not matter
        c.settings.save();

        System.out.println("== login / starting balance");
        PlayerRecord owner = c.players.onLogin(ownerId, "Maro").record();
        PlayerRecord admin = c.players.onLogin(adminId, "Admin").record();
        PlayerRecord bob = c.players.onLogin(bobId, "Bob").record();
        PlayerRecord alice = c.players.onLogin(aliceId, "Alice").record();
        check(bob.balance == 1000, "new player gets starting balance");
        check(!c.players.onLogin(bobId, "Bob").created(), "second login does not create again");
        check(bob.balance == 1000, "second login does not re-grant balance");
        check(c.permissions.isOwner(ownerId), "owner recognised from UUID with different format");
        check(!c.permissions.isOwner(adminId), "ordinary player is not owner");

        System.out.println("== permission enforcement (server side)");
        var r = act(c, bobId, "Bob", ActionType.LIST_PLAYERS, "", "", "", 0);
        check(r.views().stream().noneMatch(v -> v.name().equals("players")), "normal player cannot list players");
        check(toastKey(r).equals("msg.no_permission"), "normal player gets no_permission");
        r = act(c, bobId, "Bob", ActionType.BAL_ADD, alice.uuid, "", "", 500);
        check(alice.balance == 1000, "normal player cannot add balance (balance unchanged)");
        r = act(c, bobId, "Bob", ActionType.STAFF_ADD, bob.uuid, "", "", 0);
        check(!bob.staff, "normal player cannot make himself staff");
        r = act(c, bobId, "Bob", ActionType.SETTINGS_SET, "", "startingBalance", "99999", 0);
        check(c.settings.get().startingBalance == 1000, "normal player cannot change settings");
        r = act(c, bobId, "Bob", ActionType.LOGS, "", "", "", 0);
        check(r.views().stream().noneMatch(v -> v.name().equals("logs")), "normal player cannot read logs");
        check(c.store.adminLog().stream().anyMatch(e -> e.action.startsWith("DENIED:") && e.actorName.equals("Bob")), "denied attempts are audit-logged");

        System.out.println("== staff management and escalation limits");
        r = act(c, ownerId, "Maro", ActionType.STAFF_ADD, admin.uuid, "", "", 0);
        check(toastOk(r) && admin.staff, "owner adds staff");
        r = act(c, adminId, "Admin", ActionType.LIST_PLAYERS, "", "", "", 0);
        check(r.views().stream().noneMatch(v -> v.name().equals("players")), "staff without VIEW_PLAYERS cannot list");
        r = act(c, ownerId, "Maro", ActionType.PERM_GRANT, admin.uuid, "VIEW_PLAYERS", "", 0);
        r = act(c, ownerId, "Maro", ActionType.PERM_GRANT, admin.uuid, "EDIT_BALANCE", "", 0);
        check(c.permissions.has(adminId, Permission.VIEW_PLAYERS) && c.permissions.has(adminId, Permission.EDIT_BALANCE), "permissions granted separately");
        check(!c.permissions.has(adminId, Permission.EDIT_JOBS), "ungranted permission stays denied");
        r = act(c, adminId, "Admin", ActionType.LIST_PLAYERS, "", "", "", 0);
        check(r.views().stream().anyMatch(v -> v.name().equals("players")), "staff with VIEW_PLAYERS can list");
        r = act(c, adminId, "Admin", ActionType.PERM_GRANT, admin.uuid, "SERVER_MANAGEMENT", "", 0);
        check(!c.permissions.has(adminId, Permission.SERVER_MANAGEMENT), "staff cannot grant themselves SERVER_MANAGEMENT");
        r = act(c, adminId, "Admin", ActionType.STAFF_ADD, bob.uuid, "", "", 0);
        check(!bob.staff, "staff without MANAGE_STAFF cannot add staff");
        act(c, ownerId, "Maro", ActionType.PERM_GRANT, admin.uuid, "MANAGE_STAFF", "", 0);
        check(c.permissions.has(adminId, Permission.MANAGE_STAFF), "owner can grant MANAGE_STAFF");
        r = act(c, adminId, "Admin", ActionType.STAFF_ADD, bob.uuid, "", "", 0);
        check(bob.staff, "staff with MANAGE_STAFF can add staff");
        r = act(c, adminId, "Admin", ActionType.PERM_GRANT, bob.uuid, "EDIT_JOBS", "", 0);
        check(!c.permissions.has(bobId, Permission.EDIT_JOBS), "cannot grant a permission you do not hold");
        r = act(c, adminId, "Admin", ActionType.PERM_GRANT, bob.uuid, "VIEW_PLAYERS", "", 0);
        check(c.permissions.has(bobId, Permission.VIEW_PLAYERS), "can grant a permission you hold");
        r = act(c, adminId, "Admin", ActionType.PERM_GRANT, bob.uuid, "MANAGE_STAFF", "", 0);
        check(!c.permissions.has(bobId, Permission.MANAGE_STAFF), "MANAGE_STAFF can only be granted by owner");
        r = act(c, adminId, "Admin", ActionType.STAFF_REMOVE, owner.uuid, "", "", 0);
        check(c.permissions.isOwner(ownerId) && !toastOk(r), "staff cannot remove owner");
        r = act(c, adminId, "Admin", ActionType.PERM_REVOKE, bob.uuid, "VIEW_PLAYERS", "", 0);
        check(!c.permissions.has(bobId, Permission.VIEW_PLAYERS), "revoke works");
        r = act(c, ownerId, "Maro", ActionType.STAFF_REMOVE, bob.uuid, "", "", 0);
        check(!bob.staff && bob.permissions.isEmpty(), "removing staff clears permissions");
        act(c, ownerId, "Maro", ActionType.STAFF_ADD, bob.uuid, "", "", 0);
        act(c, ownerId, "Maro", ActionType.PERM_GRANT, bob.uuid, "MANAGE_STAFF", "", 0);
        r = act(c, adminId, "Admin", ActionType.STAFF_REMOVE, bob.uuid, "", "", 0);
        check(bob.staff, "non-owner cannot remove a staff member who holds MANAGE_STAFF");
        act(c, ownerId, "Maro", ActionType.STAFF_REMOVE, bob.uuid, "", "", 0);

        System.out.println("== owner protection");
        r = act(c, adminId, "Admin", ActionType.BAL_REMOVE, owner.uuid, "steal", "", 100);
        check(owner.balance == 1000, "staff with EDIT_BALANCE cannot touch the owner's balance");
        act(c, ownerId, "Maro", ActionType.PERM_GRANT, admin.uuid, "EDIT_JOBS", "", 0);
        r = act(c, adminId, "Admin", ActionType.SET_JOB, owner.uuid, "Police", "", 0);
        check(!owner.job.equals("Police"), "staff cannot change the owner's job");

        System.out.println("== economy invariants");
        r = act(c, adminId, "Admin", ActionType.BAL_ADD, alice.uuid, "bonus", "", 250);
        check(alice.balance == 1250, "admin add balance");
        r = act(c, adminId, "Admin", ActionType.BAL_REMOVE, alice.uuid, "fine", "", 5000);
        check(alice.balance == 1250 && !toastOk(r), "cannot remove more than balance (no negative)");
        r = act(c, adminId, "Admin", ActionType.BAL_ADD, alice.uuid, "x", "", -5);
        check(alice.balance == 1250 && !toastOk(r), "negative amount rejected");
        r = act(c, adminId, "Admin", ActionType.BAL_ADD, alice.uuid, "x", "", 0);
        check(alice.balance == 1250 && !toastOk(r), "zero amount rejected");
        r = act(c, adminId, "Admin", ActionType.BAL_ADD, alice.uuid, "x", "", Long.MAX_VALUE);
        check(alice.balance == 1250 && !toastOk(r), "huge amount rejected (no overflow)");
        r = act(c, adminId, "Admin", ActionType.BAL_SET, alice.uuid, "reset", "", 77);
        check(alice.balance == 77, "set balance");
        r = act(c, adminId, "Admin", ActionType.BAL_SET, alice.uuid, "bad", "", -1);
        check(alice.balance == 77, "set negative rejected");
        long before = bob.balance + alice.balance;
        r = act(c, bobId, "Bob", ActionType.TRANSFER, "", "Alice", "rent", 300);
        check(bob.balance == 700 && alice.balance == 377 && toastOk(r), "transfer moves money");
        check(bob.balance + alice.balance == before, "transfer conserves total money");
        check(r.notices().size() == 1 && r.notices().get(0).target().equals(aliceId), "recipient is notified");
        r = act(c, bobId, "Bob", ActionType.TRANSFER, "", "Alice", "", 10_000);
        check(bob.balance == 700 && !toastOk(r), "transfer over balance rejected");
        r = act(c, bobId, "Bob", ActionType.TRANSFER, "", "Bob", "", 1);
        check(bob.balance == 700 && !toastOk(r), "cannot pay yourself");
        r = act(c, bobId, "Bob", ActionType.TRANSFER, "", "Alice", "", -50);
        check(bob.balance == 700 && alice.balance == 377, "negative transfer cannot steal money");
        r = act(c, bobId, "Bob", ActionType.TRANSFER, "", "Nobody", "", 5);
        check(!toastOk(r), "transfer to unknown player rejected");
        c.settings.get().allowTransfers = false;
        r = act(c, bobId, "Bob", ActionType.TRANSFER, "", "Alice", "", 5);
        check(bob.balance == 700 && !toastOk(r), "transfers can be disabled");
        c.settings.get().allowTransfers = true;
        check(c.store.transactions().stream().anyMatch(t -> t.type.equals("TRANSFER") && t.amount == 300), "transfer appears in ledger");

        System.out.println("== job / rank / level validation");
        r = act(c, adminId, "Admin", ActionType.SET_JOB, alice.uuid, "police", "", 0);
        check(alice.job.equals("Police"), "job matched case-insensitively to configured value");
        r = act(c, adminId, "Admin", ActionType.SET_JOB, alice.uuid, "Hacker", "", 0);
        check(alice.job.equals("Police"), "unknown job rejected");
        r = act(c, adminId, "Admin", ActionType.SET_RANK, alice.uuid, "VIP", "", 0);
        check(!alice.rank.equals("VIP"), "EDIT_JOBS alone does not allow rank changes");
        act(c, ownerId, "Maro", ActionType.PERM_GRANT, admin.uuid, "EDIT_RANKS", "", 0);
        act(c, adminId, "Admin", ActionType.SET_RANK, alice.uuid, "VIP", "", 0);
        check(alice.rank.equals("VIP"), "rank change with EDIT_RANKS");
        act(c, adminId, "Admin", ActionType.SET_LEVEL, alice.uuid, "", "", 0);
        act(c, adminId, "Admin", ActionType.SET_LEVEL, alice.uuid, "", "", 100_000);
        check(alice.level == 1, "level out of range rejected");
        act(c, adminId, "Admin", ActionType.SET_LEVEL, alice.uuid, "", "", 12);
        check(alice.level == 12, "valid level accepted");
        check(alice.history.size() >= 3, "job/rank/level history recorded");

        System.out.println("== player-editable RP data and input sanitising");
        act(c, aliceId, "Alice", ActionType.RP_UPDATE, "", "fullName", "Alice §cEvil\u0000 Name", 0);
        check(alice.rp.fullName.equals("Alice cEvil Name"), "control chars and section sign stripped");
        act(c, aliceId, "Alice", ActionType.RP_UPDATE, "", "age", "abc", 0);
        check(alice.rp.age.isEmpty(), "non-numeric age rejected");
        act(c, aliceId, "Alice", ActionType.RP_UPDATE, "", "age", "27", 0);
        check(alice.rp.age.equals("27"), "valid age accepted");
        act(c, aliceId, "Alice", ActionType.RP_UPDATE, "", "balance", "999999", 0);
        check(alice.balance == 377, "RP_UPDATE cannot be abused to change other fields");
        act(c, aliceId, "Alice", ActionType.RP_UPDATE, "", "bio", "x".repeat(5000), 0);
        check(alice.rp.bio.length() == 200, "bio truncated to 200");
        act(c, aliceId, "Alice", ActionType.RP_UPDATE, "", "fullName", "مارو المدينة", 0);
        check(alice.rp.fullName.equals("مارو المدينة"), "Arabic text preserved");

        System.out.println("== settings");
        act(c, ownerId, "Maro", ActionType.SETTINGS_SET, "", "jobs", "Doctor, doctor, Pilot, ,Cop", 0);
        check(c.settings.get().jobs.equals(List.of("Doctor", "Pilot", "Cop")), "jobs list parsed, de-duplicated");
        r = act(c, ownerId, "Maro", ActionType.SETTINGS_SET, "", "maxBalance", "abc", 0);
        check(!toastOk(r), "invalid numeric setting rejected");
        r = act(c, ownerId, "Maro", ActionType.SETTINGS_GET, "", "", "", 0);
        JsonObject sv = r.views().get(0).data();
        check(!sv.toString().toLowerCase().contains("owner"), "settings view never leaks owner UUIDs");
        r = act(c, ownerId, "Maro", ActionType.SELF, "", "", "", 0);
        check(!r.views().get(0).data().toString().contains(ownerId.toString()) || r.views().get(0).data().get("uuid").getAsString().equals(ownerId.toString()), "self view sane");
        c.settings.get().jobs = new java.util.ArrayList<>(List.of("Unemployed", "Citizen", "Police"));

        System.out.println("== statistics counters");
        c.players.addPlaySeconds(bobId, 3600);
        c.players.addKill(bobId, true);
        c.players.addKill(bobId, false);
        c.players.addDeath(bobId);
        c.players.addAdvancement(bobId);
        check(bob.playSeconds == 3600 && bob.kills == 1 && bob.mobKills == 1 && bob.deaths == 1 && bob.advancements == 1, "play time / kills / deaths / advancements");

        System.out.println("== persistence across restart");
        c.saveAll();
        long bobBal = bob.balance, aliceBal = alice.balance;
        int txCount = c.store.transactions().size(), logCount = c.store.adminLog().size();
        TabletCore c2 = boot(dir, clock);
        PlayerRecord bob2 = c2.store.get(bobId), alice2 = c2.store.get(aliceId);
        check(bob2 != null && bob2.balance == bobBal && alice2.balance == aliceBal, "balances survive restart");
        check(alice2.job.equals("Police") && alice2.rank.equals("VIP") && alice2.level == 12, "job/rank/level survive restart");
        check(alice2.rp.age.equals("27"), "RP data survives restart");
        check(c2.store.transactions().size() == txCount, "ledger survives restart");
        check(c2.store.adminLog().size() == logCount, "admin log survives restart");
        check(c2.permissions.has(adminId, Permission.EDIT_BALANCE) && c2.permissions.isOwner(ownerId), "staff permissions and owner survive restart");
        check(bob2.playSeconds == 3600 && bob2.kills == 1, "stats survive restart");
        long nextId = c2.store.nextTransactionId();
        check(nextId > c.store.transactions().stream().mapToLong(t -> t.id).max().orElse(0), "transaction ids keep increasing after restart");

        System.out.println("== corrupt file handling");
        Files.writeString(dir.resolve("data").resolve("players.json"), "{ this is not json");
        TabletCore c3 = boot(dir, clock);
        check(c3.store.players().isEmpty(), "corrupt players.json does not crash (starts empty)");
        try (var s = Files.list(dir.resolve("data"))) {
            check(s.anyMatch(p -> p.getFileName().toString().startsWith("players.json.corrupt-")), "corrupt file kept aside, not deleted");
        }

        System.out.println("\nRESULT: " + passed + " passed, " + failed + " failed");
        System.exit(failed == 0 ? 0 : 1);
    }
}
