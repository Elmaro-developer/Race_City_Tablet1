#!/usr/bin/env python3
"""Every translation key used in Java (Ui.tr / translatable / OpResult keys) must exist in en_us.json and ar_sa.json."""
import json, re, sys, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
lang = root / "src/main/resources/assets/marocitytablet/lang"
en = json.load(open(lang / "en_us.json", encoding="utf-8"))
ar = json.load(open(lang / "ar_sa.json", encoding="utf-8"))
P = "marocitytablet."
used = set()
src = "\n".join(p.read_text(encoding="utf-8") for p in (root / "src/main/java").rglob("*.java"))
for m in re.finditer(r'Ui\.tr\(\s*"([^"]+)"', src): used.add(m.group(1))
for m in re.finditer(r'\b(?:fail|ok)\(\s*(?:src,\s*)?"([a-z_.]+)"', src): used.add(m.group(1))
for m in re.finditer(r'\bbtn\(\s*"([a-z_.]+)"', src): used.add(m.group(1))
for m in re.finditer(r'\bedit\([^;]*?,\s*"([a-z_.]+)"\);', src):
    if "." in m.group(1) and not m.group(1).startswith(("tx.", "rp.", "players.q", "staff.add", "d.", "set.")): used.add(m.group(1))
for m in re.finditer(r'"((?:card|stat|detail|rp|wallet|history|dashboard|staff|players|profile|logs|settings|ui)\.[a-z_]+)"', src): used.add(m.group(1))
for m in re.finditer(r'"(msg\.[a-z_]+)"', src): used.add(m.group(1))
# dynamic prefixes
for p in Permission_names if (Permission_names := [n.lower() for n in re.findall(r'^\s+([A-Z_]+)[,;]', (root/"src/main/java/com/maro/marocitytablet/permissions/Permission.java").read_text(), re.M)]) else []:
    used.add("permission." + p)
for k in ("tab.profile","tab.wallet","tab.rp","tab.history","tab.dashboard","tab.players","tab.staff","tab.stats","tab.logs","tab.settings",
          "history.type.job","history.type.rank","history.type.level"): used.add(k)
for k in ("cityName","currencySymbol","startingBalance","maxBalance","maxLevel","jobs","ranks","allowTransfers","giveTabletOnFirstJoin"): used.add("setting." + k)
# keys that look like internal field ids, not translation keys
ignore = {"history.type.","permission.","setting.","tab.","players.json","rp.fullName","rp.age","rp.gender","rp.phone","rp.bio","tx.to","tx.amount","tx.note","players.q","staff.add_field","msg.","rp.save_field"}
missing = sorted(k for k in used if k not in ignore and (P + k not in en or P + k not in ar))
extra = sorted(k for k in en if k.startswith(P) and k[len(P):] not in used)
print(f"{len(used)} keys referenced in code")
if missing:
    print("MISSING:", *missing, sep="\n  "); sys.exit(1)
print("OK: all referenced keys exist in en_us and ar_sa")
if extra: print("unused (harmless):", len(extra))
