package com.maro.marocitytablet.admin;

import java.util.UUID;

/** Lets the pure-Java core ask the game which players are online, without depending on Minecraft classes. */
public interface OnlineInfo {
    boolean isOnline(UUID uuid);

    int onlineCount();
}
