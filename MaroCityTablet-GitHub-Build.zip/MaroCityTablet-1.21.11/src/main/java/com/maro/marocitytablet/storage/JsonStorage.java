package com.maro.marocitytablet.storage;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Crash-safe JSON persistence: write to a temp file, then atomically move over the real file. */
public final class JsonStorage {
    private static final Logger LOG = Logger.getLogger("marocitytablet");
    public static final Gson GSON = new GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create();
    private static final Gson COMPACT = new GsonBuilder().disableHtmlEscaping().create();

    private JsonStorage() {}

    /**
     * Reads a JSON file. A missing file yields the default. A corrupt file is renamed to
     * {@code *.corrupt-<time>} (never silently overwritten) and the default is returned.
     */
    public static <T> T read(Path file, Type type, Supplier<T> def) {
        if (!Files.exists(file)) return def.get();
        try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            T v = GSON.fromJson(r, type);
            return v != null ? v : def.get();
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Corrupt data file " + file + ", moving it aside", e);
            try {
                Files.move(file, file.resolveSibling(file.getFileName() + ".corrupt-" + System.currentTimeMillis()),
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ioe) {
                LOG.log(Level.SEVERE, "Could not move corrupt file aside", ioe);
            }
            return def.get();
        }
    }

    public static void write(Path file, Object data, boolean pretty) throws IOException {
        Files.createDirectories(file.toAbsolutePath().getParent());
        Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
        try (Writer w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
            (pretty ? GSON : COMPACT).toJson(data, w);
        }
        try {
            Files.move(tmp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
