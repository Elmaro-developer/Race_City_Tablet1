package com.maro.marocitytablet.config;

import com.maro.marocitytablet.storage.JsonStorage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Loads and saves {@link ServerSettings} and answers "is this UUID a primary owner?". */
public final class SettingsManager {
    private static final Logger LOG = Logger.getLogger("marocitytablet");

    private final Path file;
    private ServerSettings settings = new ServerSettings();

    public SettingsManager(Path file) {
        this.file = file;
    }

    public ServerSettings get() {
        return settings;
    }

    public void load() {
        boolean existed = Files.exists(file);
        settings = JsonStorage.read(file, ServerSettings.class, ServerSettings::new);
        settings.sanitize();
        if (!existed) save();
        if (settings.ownerUuids.isEmpty()) {
            LOG.warning("[MaroCityTablet] No owner configured. Add your UUID to ownerUuids in " + file
                    + " (or run /marocity claimowner in single player) to use the Owner Tablet.");
        }
    }

    public void save() {
        try {
            JsonStorage.write(file, settings, true);
        } catch (IOException e) {
            LOG.log(Level.SEVERE, "Could not save settings", e);
        }
    }

    public boolean isOwner(UUID uuid) {
        if (uuid == null) return false;
        String want = normalise(uuid.toString());
        for (String s : settings.ownerUuids) {
            if (s != null && normalise(s).equals(want)) return true;
        }
        return false;
    }

    /** Only used by the single-player claim command. Returns false if the UUID is already an owner. */
    public boolean addOwner(UUID uuid) {
        if (isOwner(uuid)) return false;
        settings.ownerUuids.add(uuid.toString());
        save();
        return true;
    }

    private static String normalise(String s) {
        return s.trim().replace("-", "").toLowerCase(Locale.ROOT);
    }
}
