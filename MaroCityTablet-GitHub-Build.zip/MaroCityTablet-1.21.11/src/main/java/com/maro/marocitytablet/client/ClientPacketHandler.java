package com.maro.marocitytablet.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.maro.marocitytablet.admin.ActionType;
import com.maro.marocitytablet.items.TabletKind;
import com.maro.marocitytablet.networking.ActionPacket;
import com.maro.marocitytablet.networking.ModNetwork;
import com.maro.marocitytablet.screens.OwnerTabletScreen;
import com.maro.marocitytablet.screens.PlayerTabletScreen;
import com.maro.marocitytablet.screens.TabletScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraftforge.network.PacketDistributor;

/**
 * Client-only entry points for packets. This class is only ever loaded when a packet arrives on a client, so the
 * dedicated server never touches {@code net.minecraft.client}.
 */
public final class ClientPacketHandler {
    private ClientPacketHandler() {}

    public static void openTablet(TabletKind kind, String selfJson) {
        JsonObject self = JsonParser.parseString(selfJson).getAsJsonObject();
        Minecraft mc = Minecraft.getInstance();
        mc.setScreen(kind == TabletKind.OWNER ? new OwnerTabletScreen(self) : new PlayerTabletScreen(self));
    }

    public static void onView(String name, String json) {
        Screen current = Minecraft.getInstance().screen;
        if (current instanceof TabletScreen tablet) {
            tablet.onView(name, JsonParser.parseString(json).getAsJsonObject());
        }
    }

    /** Sends a request to the server. The server validates everything; nothing here is trusted. */
    public static void send(ActionType type, String target, String a, String b, long n) {
        ModNetwork.CHANNEL.send(new ActionPacket(type, cut(target, ActionPacket.MAX_TARGET), cut(a, ActionPacket.MAX_ARG),
                cut(b, ActionPacket.MAX_ARG), n), PacketDistributor.SERVER.noArg());
    }

    private static String cut(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max);
    }
}
