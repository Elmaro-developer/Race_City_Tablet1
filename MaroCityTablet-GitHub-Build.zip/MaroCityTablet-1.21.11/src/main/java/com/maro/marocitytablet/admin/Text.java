package com.maro.marocitytablet.admin;

/** Sanitising helpers for every string that comes from a client. */
public final class Text {
    private Text() {}

    /** Removes control characters and the legacy formatting marker, trims and truncates. Never returns null. */
    public static String clean(String s, int maxLen) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(Math.min(s.length(), maxLen));
        for (int i = 0; i < s.length() && sb.length() < maxLen; i++) {
            char c = s.charAt(i);
            if (Character.isISOControl(c) || c == '§') continue;
            sb.append(c);
        }
        return sb.toString().trim();
    }
}
