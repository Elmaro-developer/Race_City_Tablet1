package com.maro.marocitytablet.networking;

import com.maro.marocitytablet.main.MaroCityTablet;
import net.minecraft.resources.Identifier;
import net.minecraftforge.network.Channel.VersionTest;
import net.minecraftforge.network.ChannelBuilder;
import net.minecraftforge.network.SimpleChannel;

/**
 * The single play-phase channel. Clients and servers must run the same protocol version, otherwise the connection
 * is refused with Forge's standard mismatch screen.
 */
public final class ModNetwork {
    public static final Identifier CHANNEL_NAME = Identifier.fromNamespaceAndPath(MaroCityTablet.MOD_ID, "main");
    public static final int PROTOCOL_VERSION = 1;

    public static final SimpleChannel CHANNEL = ChannelBuilder
            .named(CHANNEL_NAME)
            .networkProtocolVersion(PROTOCOL_VERSION)
            .clientAcceptedVersions(VersionTest.exact(PROTOCOL_VERSION))
            .serverAcceptedVersions(VersionTest.exact(PROTOCOL_VERSION))
            .simpleChannel()
                .play()
                    .clientbound()
                        .addMain(OpenTabletPacket.class, OpenTabletPacket.STREAM_CODEC, OpenTabletPacket::handle)
                        .addMain(ViewPacket.class, ViewPacket.STREAM_CODEC, ViewPacket::handle)
                    .serverbound()
                        .addMain(ActionPacket.class, ActionPacket.STREAM_CODEC, ActionPacket::handle)
            .build();

    private ModNetwork() {}

    /** Forces class initialisation (and therefore channel registration) during common setup. */
    public static void init() {
        MaroCityTablet.LOGGER.debug("Registered network channel {} protocol {}", CHANNEL.getName(), CHANNEL.getProtocolVersion());
    }
}
