package com.maro.marocitytablet.admin;

import com.google.gson.JsonObject;
import com.maro.marocitytablet.config.ServerSettings;
import com.maro.marocitytablet.config.SettingsManager;
import com.maro.marocitytablet.economy.EconomyService;
import com.maro.marocitytablet.permissions.Permission;
import com.maro.marocitytablet.permissions.PermissionManager;
import com.maro.marocitytablet.players.PlayerRecord;
import com.maro.marocitytablet.players.PlayerService;
import com.maro.marocitytablet.storage.DataStore;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.function.LongSupplier;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * THE authority for every tablet request. The client only ever asks; this class decides. Each action:
 * 1. checks the required {@link Permission} against server-side data (never against anything the client sent),
 * 2. validates and sanitises every argument,
 * 3. protects the owner from non-owners,
 * 4. writes an audit-log entry (successes and denied attempts),
 * 5. returns fresh views for the requester.
 */
public final class ActionService {
    private static final Logger LOG = Logger.getLogger("marocitytablet");

    public record View(String name, JsonObject data) {}

    /** A chat-style message for another (possibly online) player, e.g. "you received 50 from X". */
    public record Notice(UUID target, String key, List<String> args) {}

    public record Response(List<View> views, List<Notice> notices) {}

    private final SettingsManager settings;
    private final DataStore store;
    private final PermissionManager perms;
    private final EconomyService economy;
    private final PlayerService players;
    private final ViewBuilder views;
    private final LongSupplier clock;

    public ActionService(SettingsManager settings, DataStore store, PermissionManager perms, EconomyService economy,
                         PlayerService players, ViewBuilder views, LongSupplier clock) {
        this.settings = settings;
        this.store = store;
        this.perms = perms;
        this.economy = economy;
        this.players = players;
        this.views = views;
        this.clock = clock;
    }

    // ------------------------------------------------------------------------------------------------------

    public Response handle(UUID actor, String actorName, ActionType type, String target, String a, String b, long n) {
        List<View> out = new ArrayList<>();
        List<Notice> notices = new ArrayList<>();
        try {
            target = Text.clean(target, 40);
            a = Text.clean(a, 400);
            b = Text.clean(b, 400);
            PlayerRecord me = store.get(actor);
            if (me == null) {
                out.add(toast(OpResult.fail("msg.no_profile")));
                return new Response(out, notices);
            }
            dispatch(actor, actorName, me, type, target, a, b, n, out, notices);
        } catch (RuntimeException e) {
            LOG.log(Level.SEVERE, "Error while handling " + type + " from " + actorName, e);
            out.add(toast(OpResult.fail("msg.internal_error")));
        }
        return new Response(out, notices);
    }

    private void dispatch(UUID actor, String actorName, PlayerRecord me, ActionType type, String target, String a, String b,
                          long n, List<View> out, List<Notice> notices) {
        switch (type) {
            case SELF -> out.add(new View("self", views.self(me)));

            case LIST_PLAYERS -> {
                if (!need(actor, actorName, type, Permission.VIEW_PLAYERS, out)) return;
                out.add(new View("players", views.playerList(a, (int) Math.max(0, Math.min(n, 100_000)))));
            }
            case GET_PLAYER -> {
                if (!need(actor, actorName, type, Permission.VIEW_PLAYERS, out)) return;
                PlayerRecord t = players.find(target);
                if (t == null) {
                    out.add(toast(OpResult.fail("msg.player_not_found")));
                    return;
                }
                out.add(playerView(actor, t));
            }

            case SET_JOB -> mutate(actor, actorName, me, type, Permission.EDIT_JOBS, target, out,
                    t -> players.setJob(t, a, actorName), "job=" + a);
            case SET_RANK -> mutate(actor, actorName, me, type, Permission.EDIT_RANKS, target, out,
                    t -> players.setRank(t, a, actorName), "rank=" + a);
            case SET_LEVEL -> mutate(actor, actorName, me, type, Permission.EDIT_RANKS, target, out,
                    t -> players.setLevel(t, n, actorName), "level=" + n);

            case BAL_ADD -> mutate(actor, actorName, me, type, Permission.EDIT_BALANCE, target, out,
                    t -> economy.adjust(t, EconomyService.Mode.ADD, n, actor.toString(), actorName, a), "amount=" + n + " reason=" + a);
            case BAL_REMOVE -> mutate(actor, actorName, me, type, Permission.EDIT_BALANCE, target, out,
                    t -> economy.adjust(t, EconomyService.Mode.REMOVE, n, actor.toString(), actorName, a), "amount=" + n + " reason=" + a);
            case BAL_SET -> mutate(actor, actorName, me, type, Permission.EDIT_BALANCE, target, out,
                    t -> economy.adjust(t, EconomyService.Mode.SET, n, actor.toString(), actorName, a), "amount=" + n + " reason=" + a);

            case TRANSFER -> {
                PlayerRecord to = players.find(a);
                if (to == null) {
                    out.add(toast(OpResult.fail("msg.player_not_found")));
                    return;
                }
                OpResult res = economy.transfer(me, to, n, b);
                out.add(toast(res));
                if (res.ok()) {
                    out.add(new View("self", views.self(me)));
                    out.add(new View("tx", views.myTransactions(actor, 0)));
                    notices.add(new Notice(UUID.fromString(to.uuid), "msg.transfer_received",
                            List.of(Long.toString(n), me.name)));
                }
            }

            case STAFF_LIST -> {
                if (!need(actor, actorName, type, Permission.MANAGE_STAFF, out)) return;
                out.add(new View("staff", views.staffList()));
            }
            case STAFF_ADD -> staffOp(actor, actorName, me, type, target, null, out);
            case STAFF_REMOVE -> staffOp(actor, actorName, me, type, target, null, out);
            case PERM_GRANT, PERM_REVOKE -> {
                Permission p = Permission.parse(a).orElse(null);
                if (p == null) {
                    out.add(toast(OpResult.fail("msg.unknown_permission")));
                    return;
                }
                staffOp(actor, actorName, me, type, target, p, out);
            }

            case LOGS -> {
                if (!need(actor, actorName, type, Permission.VIEW_LOGS, out)) return;
                out.add(new View("logs", views.logs((int) Math.max(0, Math.min(n, 100_000)))));
            }
            case STATS -> {
                if (!need(actor, actorName, type, Permission.VIEW_STATS, out)) return;
                out.add(new View("stats", views.stats()));
            }

            case SETTINGS_GET -> {
                if (!need(actor, actorName, type, Permission.SERVER_MANAGEMENT, out)) return;
                out.add(new View("settings", views.settingsView()));
            }
            case SETTINGS_SET -> {
                if (!need(actor, actorName, type, Permission.SERVER_MANAGEMENT, out)) return;
                OpResult res = applySetting(a, b);
                out.add(toast(res));
                if (res.ok()) {
                    log(actor, actorName, "SETTINGS_SET", null, a + "=" + b);
                    out.add(new View("settings", views.settingsView()));
                    out.add(new View("self", views.self(me)));
                }
            }

            case RP_UPDATE -> {
                OpResult res = players.updateRp(me, a, b);
                out.add(toast(res));
                out.add(new View("self", views.self(me)));
            }
            case MY_TX -> out.add(new View("tx", views.myTransactions(actor, (int) Math.max(0, Math.min(n, 100_000)))));

            case INVALID -> { /* ignored */ }
        }
    }

    // ---- helpers ------------------------------------------------------------------------------------------

    private View toast(OpResult r) {
        return new View("toast", views.toast(r));
    }

    private View playerView(UUID viewer, PlayerRecord t) {
        return new View("player", views.player(t, perms.has(viewer, Permission.MANAGE_STAFF)));
    }

    /** Permission gate. Logs and reports a denied attempt. */
    private boolean need(UUID actor, String actorName, ActionType type, Permission p, List<View> out) {
        if (perms.has(actor, p)) return true;
        log(actor, actorName, "DENIED:" + type.name(), null, "needs " + p.name());
        out.add(toast(OpResult.fail("msg.no_permission")));
        return false;
    }

    /** Generic "change something on another player" flow with permission, owner protection, audit log and refresh. */
    private void mutate(UUID actor, String actorName, PlayerRecord me, ActionType type, Permission p, String targetKey,
                        List<View> out, Function<PlayerRecord, OpResult> op, String details) {
        if (!need(actor, actorName, type, p, out)) return;
        PlayerRecord t = players.find(targetKey);
        if (t == null) {
            out.add(toast(OpResult.fail("msg.player_not_found")));
            return;
        }
        if (perms.isOwner(t) && !perms.isOwner(actor)) {
            log(actor, actorName, "DENIED:" + type.name(), t, "target is owner");
            out.add(toast(OpResult.fail("msg.target_is_owner")));
            return;
        }
        OpResult res = op.apply(t);
        out.add(toast(res));
        if (res.ok()) {
            log(actor, actorName, type.name(), t, details);
            out.add(playerView(actor, t));
            if (t.uuid.equals(me.uuid)) out.add(new View("self", views.self(me)));
        }
    }

    private void staffOp(UUID actor, String actorName, PlayerRecord me, ActionType type, String targetKey, Permission p, List<View> out) {
        PlayerRecord t = players.find(targetKey);
        if (t == null) {
            out.add(toast(OpResult.fail("msg.player_not_found")));
            return;
        }
        OpResult res = switch (type) {
            case STAFF_ADD -> perms.addStaff(actor, t);
            case STAFF_REMOVE -> perms.removeStaff(actor, t);
            case PERM_GRANT -> perms.grant(actor, t, p);
            case PERM_REVOKE -> perms.revoke(actor, t, p);
            default -> OpResult.fail("msg.internal_error");
        };
        out.add(toast(res));
        if (res.ok()) {
            log(actor, actorName, type.name(), t, p == null ? "" : p.name());
            out.add(new View("staff", views.staffList()));
            if (perms.has(actor, Permission.VIEW_PLAYERS)) out.add(playerView(actor, t));
        } else if ("msg.no_permission".equals(res.key()) || "msg.owner_only".equals(res.key())
                || "msg.cannot_grant_unheld".equals(res.key()) || "msg.target_is_owner".equals(res.key())) {
            log(actor, actorName, "DENIED:" + type.name(), t, res.key());
        }
    }

    private void log(UUID actor, String actorName, String action, PlayerRecord target, String details) {
        AdminLogEntry e = new AdminLogEntry();
        e.time = clock.getAsLong();
        e.actorUuid = actor.toString();
        e.actorName = actorName;
        e.action = action;
        if (target != null) {
            e.targetUuid = target.uuid;
            e.targetName = target.name;
        }
        e.details = Text.clean(details, 200);
        store.addAdminLog(e);
    }

    // ---- settings -----------------------------------------------------------------------------------------

    private OpResult applySetting(String key, String value) {
        ServerSettings s = settings.get();
        try {
            switch (key) {
                case "cityName" -> {
                    String v = Text.clean(value, 32);
                    if (v.isEmpty()) return OpResult.fail("msg.setting_invalid");
                    s.cityName = v;
                }
                case "currencySymbol" -> {
                    String v = Text.clean(value, 4);
                    if (v.isEmpty()) return OpResult.fail("msg.setting_invalid");
                    s.currencySymbol = v;
                }
                case "startingBalance" -> {
                    long v = Long.parseLong(value.trim());
                    if (v < 0 || v > s.maxBalance) return OpResult.fail("msg.setting_invalid");
                    s.startingBalance = v;
                }
                case "maxBalance" -> {
                    long v = Long.parseLong(value.trim());
                    if (v < 1 || v > ServerSettings.ABSOLUTE_MAX_BALANCE) return OpResult.fail("msg.setting_invalid");
                    s.maxBalance = v;
                    if (s.startingBalance > v) s.startingBalance = v;
                }
                case "maxLevel" -> {
                    long v = Long.parseLong(value.trim());
                    if (v < 1 || v > 10_000) return OpResult.fail("msg.setting_invalid");
                    s.maxLevel = (int) v;
                }
                case "allowTransfers" -> s.allowTransfers = parseBool(value);
                case "giveTabletOnFirstJoin" -> s.giveTabletOnFirstJoin = parseBool(value);
                case "jobs" -> {
                    List<String> v = parseList(value);
                    if (v.isEmpty()) return OpResult.fail("msg.setting_invalid");
                    s.jobs = v;
                }
                case "ranks" -> {
                    List<String> v = parseList(value);
                    if (v.isEmpty()) return OpResult.fail("msg.setting_invalid");
                    s.ranks = v;
                }
                default -> {
                    return OpResult.fail("msg.setting_invalid");
                }
            }
        } catch (NumberFormatException e) {
            return OpResult.fail("msg.setting_invalid");
        }
        settings.save();
        return OpResult.ok("msg.setting_saved");
    }

    private static boolean parseBool(String v) {
        return "true".equalsIgnoreCase(v.trim()) || "1".equals(v.trim()) || "on".equalsIgnoreCase(v.trim());
    }

    /** Comma separated list, trimmed, de-duplicated case-insensitively, max 64 entries of up to 24 characters. */
    static List<String> parseList(String raw) {
        Set<String> seen = new LinkedHashSet<>();
        List<String> out = new ArrayList<>();
        for (String part : raw.split(",")) {
            String v = Text.clean(part, 24);
            if (v.isEmpty()) continue;
            if (seen.add(v.toLowerCase(Locale.ROOT))) out.add(v);
            if (out.size() >= 64) break;
        }
        return out;
    }
}
