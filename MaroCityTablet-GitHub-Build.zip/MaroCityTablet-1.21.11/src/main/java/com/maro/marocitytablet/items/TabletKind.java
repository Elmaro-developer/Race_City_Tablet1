package com.maro.marocitytablet.items;

public enum TabletKind {
    OWNER,
    PLAYER;

    public static TabletKind fromOrdinal(int i) {
        return i == 0 ? OWNER : PLAYER;
    }
}
