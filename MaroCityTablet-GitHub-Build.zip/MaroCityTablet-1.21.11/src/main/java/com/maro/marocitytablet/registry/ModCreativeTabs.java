package com.maro.marocitytablet.registry;

import com.maro.marocitytablet.main.MaroCityTablet;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.RegisterEvent;

public final class ModCreativeTabs {
    public static final ResourceKey<CreativeModeTab> MAIN = ResourceKey.create(Registries.CREATIVE_MODE_TAB,
            Identifier.fromNamespaceAndPath(MaroCityTablet.MOD_ID, "main"));

    private ModCreativeTabs() {}

    public static void onRegister(RegisterEvent event) {
        event.register(Registries.CREATIVE_MODE_TAB, helper -> helper.register(MAIN, CreativeModeTab.builder()
                .title(Component.translatable("itemGroup.marocitytablet.main"))
                .icon(() -> new ItemStack(ModItems.PLAYER_TABLET.get()))
                .displayItems((params, output) -> {
                    output.accept(ModItems.PLAYER_TABLET.get());
                    output.accept(ModItems.OWNER_TABLET.get());
                })
                .build()));
    }
}
