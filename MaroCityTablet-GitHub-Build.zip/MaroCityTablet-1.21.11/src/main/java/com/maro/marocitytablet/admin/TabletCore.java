package com.maro.marocitytablet.admin;

import com.maro.marocitytablet.config.SettingsManager;
import com.maro.marocitytablet.economy.EconomyService;
import com.maro.marocitytablet.permissions.PermissionManager;
import com.maro.marocitytablet.players.PlayerService;
import com.maro.marocitytablet.storage.DataStore;

import java.nio.file.Path;
import java.util.function.LongSupplier;

/**
 * Wires the whole server-side logic together. It has no dependency on Minecraft classes, which is what makes it
 * possible to unit-test (see {@code selftest/CoreSelfTest.java}).
 */
public final class TabletCore {
    public final SettingsManager settings;
    public final DataStore store;
    public final PermissionManager permissions;
    public final EconomyService economy;
    public final PlayerService players;
    public final ViewBuilder views;
    public final ActionService actions;

    public TabletCore(Path settingsFile, Path dataDir, LongSupplier clock, OnlineInfo online) {
        this.settings = new SettingsManager(settingsFile);
        this.store = new DataStore(dataDir);
        this.permissions = new PermissionManager(settings, store);
        this.economy = new EconomyService(store, settings, clock);
        this.players = new PlayerService(store, settings, economy, clock);
        this.views = new ViewBuilder(settings, store, permissions, players, online);
        this.actions = new ActionService(settings, store, permissions, economy, players, views, clock);
    }

    public void load() {
        settings.load();
        store.load();
    }

    public void saveAll() {
        store.saveAll();
    }
}
