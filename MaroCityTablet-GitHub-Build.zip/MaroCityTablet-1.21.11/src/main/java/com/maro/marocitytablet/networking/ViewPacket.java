package com.maro.marocitytablet.networking;

import com.maro.marocitytablet.client.ClientPacketHandler;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Server to client: one named JSON document ("self", "players", "logs", "toast", ...). */
public record ViewPacket(String name, String json) {
    public static final int MAX_JSON = 262_144;

    public static final StreamCodec<RegistryFriendlyByteBuf, ViewPacket> STREAM_CODEC =
            StreamCodec.ofMember(ViewPacket::encode, ViewPacket::decode);

    public static void encode(ViewPacket p, RegistryFriendlyByteBuf buf) {
        buf.writeUtf(p.name, 32);
        buf.writeUtf(p.json, MAX_JSON);
    }

    public static ViewPacket decode(RegistryFriendlyByteBuf buf) {
        return new ViewPacket(buf.readUtf(32), buf.readUtf(MAX_JSON));
    }

    /** Only ever invoked on a client. */
    public static void handle(ViewPacket packet, CustomPayloadEvent.Context ctx) {
        ClientPacketHandler.onView(packet.name, packet.json);
    }
}
