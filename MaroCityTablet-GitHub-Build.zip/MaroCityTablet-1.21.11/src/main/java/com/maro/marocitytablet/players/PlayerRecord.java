package com.maro.marocitytablet.players;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Everything the server persists about one player. Keyed by UUID string in the store. */
public final class PlayerRecord {
    public String uuid;
    public String name;

    public String job = "Unemployed";
    public String rank = "Citizen";
    public int level = 1;
    public long balance;

    public long playSeconds;
    public int kills;
    public int mobKills;
    public int deaths;
    public int advancements;

    public long firstJoin;
    public long lastSeen;

    public boolean staff;
    /** Names of {@link com.maro.marocitytablet.permissions.Permission}. Meaningful only while {@link #staff}. */
    public Set<String> permissions = new LinkedHashSet<>();

    public Rp rp = new Rp();
    public List<HistoryEntry> history = new ArrayList<>();

    public static final class Rp {
        public String fullName = "";
        public String age = "";
        public String gender = "";
        public String phone = "";
        public String bio = "";
    }

    public static final class HistoryEntry {
        public long time;
        /** JOB, RANK or LEVEL. */
        public String type;
        public String from;
        public String to;
        public String by;

        public HistoryEntry() {}

        public HistoryEntry(long time, String type, String from, String to, String by) {
            this.time = time;
            this.type = type;
            this.from = from;
            this.to = to;
            this.by = by;
        }
    }

    /** Fills fields that are null because the JSON file was written by an older version or edited by hand. */
    public void normalise() {
        if (permissions == null) permissions = new LinkedHashSet<>();
        if (rp == null) rp = new Rp();
        if (history == null) history = new ArrayList<>();
        if (job == null) job = "Unemployed";
        if (rank == null) rank = "Citizen";
        if (name == null) name = uuid;
        if (level < 1) level = 1;
        if (balance < 0) balance = 0;
    }

    public void addHistory(HistoryEntry e) {
        history.add(e);
        while (history.size() > 100) history.remove(0);
    }
}
