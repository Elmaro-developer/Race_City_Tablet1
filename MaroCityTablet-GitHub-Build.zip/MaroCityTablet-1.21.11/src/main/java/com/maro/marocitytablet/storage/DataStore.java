package com.maro.marocitytablet.storage;

import com.google.gson.reflect.TypeToken;
import com.maro.marocitytablet.admin.AdminLogEntry;
import com.maro.marocitytablet.economy.Transaction;
import com.maro.marocitytablet.players.PlayerRecord;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * In-memory view of the three data files (players, transactions, admin log). All access must happen on the
 * server thread. Changes are flushed by {@link #saveIfDirty()} (periodically and on logout) and {@link #saveAll()}
 * (on server stop), so nothing is lost when the server shuts down.
 */
public final class DataStore {
    private static final Logger LOG = Logger.getLogger("marocitytablet");

    public static final int MAX_TRANSACTIONS = 50_000;
    public static final int MAX_ADMIN_LOG = 50_000;

    private final Path dir;
    private Map<String, PlayerRecord> players = new LinkedHashMap<>();
    private List<Transaction> transactions = new ArrayList<>();
    private List<AdminLogEntry> adminLog = new ArrayList<>();
    private long nextTxId = 1;
    private long nextLogId = 1;
    private boolean dirtyPlayers, dirtyTx, dirtyLog;

    public DataStore(Path dir) {
        this.dir = dir;
    }

    // ---- file layout --------------------------------------------------------------------------------------

    private static final class PlayersFile {
        int version = 1;
        Map<String, PlayerRecord> players = new LinkedHashMap<>();
    }

    private static final class TxFile {
        int version = 1;
        long nextId = 1;
        List<Transaction> entries = new ArrayList<>();
    }

    private static final class LogFile {
        int version = 1;
        long nextId = 1;
        List<AdminLogEntry> entries = new ArrayList<>();
    }

    private Path playersFile() { return dir.resolve("players.json"); }
    private Path txFile() { return dir.resolve("transactions.json"); }
    private Path logFile() { return dir.resolve("adminlog.json"); }

    public void load() {
        PlayersFile pf = JsonStorage.read(playersFile(), new TypeToken<PlayersFile>() {}.getType(), PlayersFile::new);
        players = pf.players != null ? pf.players : new LinkedHashMap<>();
        players.forEach((k, v) -> {
            v.uuid = k;
            v.normalise();
        });

        TxFile tf = JsonStorage.read(txFile(), new TypeToken<TxFile>() {}.getType(), TxFile::new);
        transactions = tf.entries != null ? tf.entries : new ArrayList<>();
        nextTxId = Math.max(tf.nextId, transactions.stream().mapToLong(t -> t.id).max().orElse(0) + 1);

        LogFile lf = JsonStorage.read(logFile(), new TypeToken<LogFile>() {}.getType(), LogFile::new);
        adminLog = lf.entries != null ? lf.entries : new ArrayList<>();
        nextLogId = Math.max(lf.nextId, adminLog.stream().mapToLong(t -> t.id).max().orElse(0) + 1);
    }

    public void saveAll() {
        dirtyPlayers = dirtyTx = dirtyLog = true;
        saveIfDirty();
    }

    public void saveIfDirty() {
        try {
            if (dirtyPlayers) {
                PlayersFile pf = new PlayersFile();
                pf.players = players;
                JsonStorage.write(playersFile(), pf, true);
                dirtyPlayers = false;
            }
            if (dirtyTx) {
                TxFile tf = new TxFile();
                tf.nextId = nextTxId;
                tf.entries = transactions;
                JsonStorage.write(txFile(), tf, false);
                dirtyTx = false;
            }
            if (dirtyLog) {
                LogFile lf = new LogFile();
                lf.nextId = nextLogId;
                lf.entries = adminLog;
                JsonStorage.write(logFile(), lf, false);
                dirtyLog = false;
            }
        } catch (IOException e) {
            LOG.log(Level.SEVERE, "Failed to save MaroCityTablet data (will retry)", e);
        }
    }

    // ---- players ------------------------------------------------------------------------------------------

    public Map<String, PlayerRecord> players() {
        return players;
    }

    public PlayerRecord get(UUID uuid) {
        return players.get(uuid.toString());
    }

    public PlayerRecord get(String uuid) {
        return players.get(uuid);
    }

    public PlayerRecord put(PlayerRecord r) {
        players.put(r.uuid, r);
        dirtyPlayers = true;
        return r;
    }

    /** Case-insensitive exact name match. */
    public PlayerRecord findByName(String name) {
        if (name == null) return null;
        String n = name.trim().toLowerCase(Locale.ROOT);
        for (PlayerRecord r : players.values()) {
            if (r.name != null && r.name.toLowerCase(Locale.ROOT).equals(n)) return r;
        }
        return null;
    }

    public void markPlayersDirty() {
        dirtyPlayers = true;
    }

    // ---- ledger and audit log -----------------------------------------------------------------------------

    public List<Transaction> transactions() {
        return transactions;
    }

    public long nextTransactionId() {
        return nextTxId++;
    }

    public void addTransaction(Transaction t) {
        transactions.add(t);
        while (transactions.size() > MAX_TRANSACTIONS) transactions.remove(0);
        dirtyTx = true;
    }

    public List<AdminLogEntry> adminLog() {
        return adminLog;
    }

    public void addAdminLog(AdminLogEntry e) {
        e.id = nextLogId++;
        adminLog.add(e);
        while (adminLog.size() > MAX_ADMIN_LOG) adminLog.remove(0);
        dirtyLog = true;
    }
}
