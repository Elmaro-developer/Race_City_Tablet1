package com.maro.marocitytablet.screens;

import com.google.gson.JsonObject;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Colour palette (dark black / gold / dark red), drawing helpers and number/date formatting for the tablets. */
public final class Ui {
    // ARGB. The alpha byte must always be 0xFF, otherwise the colour is invisible in recent Minecraft versions.
    public static final int BG = 0xFF08080A;
    public static final int PANEL = 0xFF121215;
    public static final int PANEL_2 = 0xFF1A1A1F;
    public static final int SIDEBAR_OWNER = 0xFF2A070A;
    public static final int SIDEBAR_PLAYER = 0xFF0E0E12;
    public static final int GOLD = 0xFFD4AF37;
    public static final int GOLD_DIM = 0xFF8A7226;
    public static final int RED = 0xFF9B111E;
    public static final int RED_DARK = 0xFF5C0A12;
    public static final int TEXT = 0xFFEDEDED;
    public static final int MUTED = 0xFF9A9AA2;
    public static final int GOOD = 0xFF5CBF60;
    public static final int BAD = 0xFFE05252;

    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.systemDefault());
    private static final DateTimeFormatter DATE_SHORT = DateTimeFormatter.ofPattern("MM-dd HH:mm").withZone(ZoneId.systemDefault());

    private Ui() {}

    /** Translation helper: every key of this mod lives under the "marocitytablet." prefix. */
    public static MutableComponent tr(String key, Object... args) {
        return Component.translatable("marocitytablet." + key, args);
    }

    // ---- drawing ------------------------------------------------------------------------------------------

    public static void rect(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + h, color);
    }

    public static void border(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    /** A card: dark body with a thin gold accent on the left. */
    public static void card(GuiGraphics g, int x, int y, int w, int h) {
        rect(g, x, y, w, h, PANEL_2);
        rect(g, x, y, 2, h, GOLD_DIM);
    }

    public static void text(GuiGraphics g, Font font, String s, int x, int y, int color) {
        g.drawString(font, Component.literal(s), x, y, color);
    }

    public static void text(GuiGraphics g, Font font, Component c, int x, int y, int color) {
        g.drawString(font, c, x, y, color);
    }

    public static void centered(GuiGraphics g, Font font, String s, int cx, int y, int color) {
        g.drawString(font, Component.literal(s), cx - font.width(s) / 2, y, color);
    }

    public static void right(GuiGraphics g, Font font, String s, int rightX, int y, int color) {
        g.drawString(font, Component.literal(s), rightX - font.width(s), y, color);
    }

    /** Truncates to the given pixel width, adding an ellipsis when something was cut. */
    public static String fit(Font font, String s, int maxWidth) {
        if (s == null) return "";
        if (font.width(s) <= maxWidth) return s;
        return font.plainSubstrByWidth(s, Math.max(0, maxWidth - font.width("..."))) + "...";
    }

    /** Draws coloured segments one after another, stopping at maxX. Segments are String[]{text} + colour. */
    public static void sequence(GuiGraphics g, Font font, int x, int y, int maxX, Object... partsAndColours) {
        int cx = x;
        for (int i = 0; i + 1 < partsAndColours.length; i += 2) {
            String part = String.valueOf(partsAndColours[i]);
            int colour = (Integer) partsAndColours[i + 1];
            int room = maxX - cx;
            if (room <= 4) return;
            String shown = fit(font, part, room);
            g.drawString(font, Component.literal(shown), cx, y, colour);
            cx += font.width(shown);
            if (!shown.equals(part)) return;
        }
    }

    // ---- formatting ---------------------------------------------------------------------------------------

    public static String money(long v, String currency) {
        return String.format(Locale.US, "%,d", v) + " " + currency;
    }

    public static String number(long v) {
        return String.format(Locale.US, "%,d", v);
    }

    public static String duration(long seconds) {
        long h = seconds / 3600;
        long m = (seconds % 3600) / 60;
        return h + "h " + String.format(Locale.US, "%02d", m) + "m";
    }

    public static String date(long millis) {
        return millis <= 0 ? "-" : DATE.format(Instant.ofEpochMilli(millis));
    }

    public static String dateShort(long millis) {
        return millis <= 0 ? "-" : DATE_SHORT.format(Instant.ofEpochMilli(millis));
    }

    // ---- JSON accessors that never throw ------------------------------------------------------------------

    public static String str(JsonObject o, String key) {
        return o != null && o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : "";
    }

    public static long num(JsonObject o, String key) {
        try {
            return o != null && o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsLong() : 0L;
        } catch (RuntimeException e) {
            return 0L;
        }
    }

    /** Returns the nested object, or an empty object when absent. */
    public static JsonObject obj(JsonObject o, String key) {
        return o != null && o.has(key) && o.get(key).isJsonObject() ? o.getAsJsonObject(key) : new JsonObject();
    }

    public static boolean bool(JsonObject o, String key) {
        return o != null && o.has(key) && !o.get(key).isJsonNull() && o.get(key).getAsBoolean();
    }
}
