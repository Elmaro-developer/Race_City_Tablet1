package com.maro.marocitytablet.networking;

import com.maro.marocitytablet.client.ClientPacketHandler;
import com.maro.marocitytablet.items.TabletKind;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Server to client: open a tablet screen with the viewer's own profile. Sent only after the server approved it. */
public record OpenTabletPacket(TabletKind kind, String selfJson) {
    public static final StreamCodec<RegistryFriendlyByteBuf, OpenTabletPacket> STREAM_CODEC =
            StreamCodec.ofMember(OpenTabletPacket::encode, OpenTabletPacket::decode);

    public static void encode(OpenTabletPacket p, RegistryFriendlyByteBuf buf) {
        buf.writeVarInt(p.kind.ordinal());
        buf.writeUtf(p.selfJson, ViewPacket.MAX_JSON);
    }

    public static OpenTabletPacket decode(RegistryFriendlyByteBuf buf) {
        return new OpenTabletPacket(TabletKind.fromOrdinal(buf.readVarInt()), buf.readUtf(ViewPacket.MAX_JSON));
    }

    public static void handle(OpenTabletPacket packet, CustomPayloadEvent.Context ctx) {
        ClientPacketHandler.openTablet(packet.kind, packet.selfJson);
    }
}
