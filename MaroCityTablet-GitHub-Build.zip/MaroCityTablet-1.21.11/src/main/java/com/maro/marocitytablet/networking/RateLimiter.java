package com.maro.marocitytablet.networking;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Fixed-window limiter so a modified client cannot flood the server with tablet requests. */
public final class RateLimiter {
    private final int maxPerWindow;
    private final long windowMillis;
    private final Map<UUID, long[]> state = new HashMap<>();

    public RateLimiter(int maxPerWindow, long windowMillis) {
        this.maxPerWindow = maxPerWindow;
        this.windowMillis = windowMillis;
    }

    public boolean allow(UUID id, long nowMillis) {
        long[] s = state.computeIfAbsent(id, k -> new long[]{nowMillis, 0});
        if (nowMillis - s[0] >= windowMillis) {
            s[0] = nowMillis;
            s[1] = 0;
        }
        return ++s[1] <= maxPerWindow;
    }

    public void forget(UUID id) {
        state.remove(id);
    }
}
