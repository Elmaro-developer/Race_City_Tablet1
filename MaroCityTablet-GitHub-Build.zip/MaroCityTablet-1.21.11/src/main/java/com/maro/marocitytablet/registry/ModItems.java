package com.maro.marocitytablet.registry;

import com.maro.marocitytablet.items.TabletItem;
import com.maro.marocitytablet.items.TabletKind;
import com.maro.marocitytablet.main.MaroCityTablet;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.eventbus.api.bus.BusGroup;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    private static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MaroCityTablet.MOD_ID);

    public static final RegistryObject<Item> OWNER_TABLET = ITEMS.register("owner_tablet", () ->
            new TabletItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).setId(ITEMS.key("owner_tablet")), TabletKind.OWNER));

    public static final RegistryObject<Item> PLAYER_TABLET = ITEMS.register("player_tablet", () ->
            new TabletItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE).setId(ITEMS.key("player_tablet")), TabletKind.PLAYER));

    private ModItems() {}

    public static void register(BusGroup modBus) {
        ITEMS.register(modBus);
    }
}
