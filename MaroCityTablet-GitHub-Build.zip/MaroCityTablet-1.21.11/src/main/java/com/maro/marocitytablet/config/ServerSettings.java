package com.maro.marocitytablet.config;

import java.util.ArrayList;
import java.util.List;

/**
 * Server-side settings, stored as JSON in {@code config/marocitytablet-server.json}.
 * {@link #ownerUuids} is never sent to clients and can only be changed by editing this file on the server.
 */
public final class ServerSettings {
    public int configVersion = 1;

    /** UUIDs (with or without dashes) of primary owners. They hold every permission. */
    public List<String> ownerUuids = new ArrayList<>();

    public String cityName = "Maro City";
    public String currencySymbol = "$";
    public long startingBalance = 1000L;
    public long maxBalance = 1_000_000_000L;
    public boolean allowTransfers = true;
    public boolean giveTabletOnFirstJoin = true;
    public int maxLevel = 100;

    public List<String> jobs = new ArrayList<>(List.of(
            "Unemployed", "Citizen", "Police", "Paramedic", "Mechanic", "Driver", "Merchant", "Judge", "Mayor"));
    public List<String> ranks = new ArrayList<>(List.of(
            "Citizen", "Member", "VIP", "Officer", "Senior", "Chief"));

    public static final long ABSOLUTE_MAX_BALANCE = 1_000_000_000_000_000L;

    /** Repairs values that are missing or out of range (hand-edited files, older versions). */
    public void sanitize() {
        if (ownerUuids == null) ownerUuids = new ArrayList<>();
        if (cityName == null || cityName.isBlank()) cityName = "Maro City";
        if (currencySymbol == null || currencySymbol.isBlank()) currencySymbol = "$";
        if (jobs == null || jobs.isEmpty()) jobs = new ArrayList<>(List.of("Unemployed"));
        if (ranks == null || ranks.isEmpty()) ranks = new ArrayList<>(List.of("Citizen"));
        if (maxBalance < 1 || maxBalance > ABSOLUTE_MAX_BALANCE) maxBalance = Math.min(Math.max(maxBalance, 1), ABSOLUTE_MAX_BALANCE);
        if (startingBalance < 0) startingBalance = 0;
        if (startingBalance > maxBalance) startingBalance = maxBalance;
        if (maxLevel < 1) maxLevel = 1;
        if (maxLevel > 10_000) maxLevel = 10_000;
    }
}
