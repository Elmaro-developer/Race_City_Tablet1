package com.maro.marocitytablet.screens;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.maro.marocitytablet.admin.ActionType;
import com.maro.marocitytablet.permissions.Permission;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * City management tablet (red + gold). It is only a remote control: the server decides which tabs' data it
 * will actually return and rejects every action the viewer is not entitled to. The tab list below is cosmetic.
 */
public class OwnerTabletScreen extends TabletScreen {
    private static final int STAFF_ROWS = 6;

    private String detailUuid;
    private int detailPage;
    private int playersPage, staffPage, logsPage;
    private int jobIdx, rankIdx;

    public OwnerTabletScreen(JsonObject self) {
        super(Ui.tr("owner_tablet.title"), self, "dashboard");
    }

    @Override
    protected List<Tab> tabs() {
        List<Tab> t = new ArrayList<>();
        t.add(new Tab("dashboard", "tab.dashboard"));
        if (hasPerm("VIEW_PLAYERS")) t.add(new Tab("players", "tab.players"));
        if (hasPerm("MANAGE_STAFF")) t.add(new Tab("staff", "tab.staff"));
        if (hasPerm("VIEW_STATS")) t.add(new Tab("stats", "tab.stats"));
        if (hasPerm("VIEW_LOGS")) t.add(new Tab("logs", "tab.logs"));
        if (hasPerm("SERVER_MANAGEMENT")) t.add(new Tab("settings", "tab.settings"));
        return t;
    }

    @Override
    protected int sidebarColor() {
        return Ui.SIDEBAR_OWNER;
    }

    @Override
    protected Component headerTitle() {
        return Ui.tr("tab." + tab);
    }

    @Override
    protected void onTabChanged() {
        detailUuid = null;
        detailPage = 0;
    }

    @Override
    protected void init() {
        super.init();
        if (views.isEmpty()) requestTab();
    }

    @Override
    protected void requestTab() {
        switch (tab) {
            case "dashboard" -> {
                if (hasPerm("VIEW_STATS")) send(ActionType.STATS, "", "", "", 0);
                if (hasPerm("VIEW_LOGS")) send(ActionType.LOGS, "", "", "", 0);
            }
            case "players" -> send(ActionType.LIST_PLAYERS, "", field("players.q"), "", playersPage);
            case "staff" -> send(ActionType.STAFF_LIST, "", "", "", 0);
            case "stats" -> send(ActionType.STATS, "", "", "", 0);
            case "logs" -> send(ActionType.LOGS, "", "", "", logsPage);
            case "settings" -> send(ActionType.SETTINGS_GET, "", "", "", 0);
            default -> { }
        }
    }

    @Override
    protected void viewReceived(String name, JsonObject data) {
        if (name.equals("player")) {
            syncCyclers(data);
        } else if (name.equals("settings")) {
            for (String k : new String[]{"cityName", "currencySymbol", "startingBalance", "maxBalance", "maxLevel", "jobs", "ranks"}) {
                fields.put("set." + k, Ui.str(data, k));
            }
        }
    }

    private void syncCyclers(JsonObject player) {
        jobIdx = Math.max(0, indexOf(strings(self, "jobs"), Ui.str(player, "job")));
        rankIdx = Math.max(0, indexOf(strings(self, "ranks"), Ui.str(player, "rank")));
    }

    private static List<String> strings(JsonObject o, String key) {
        List<String> out = new ArrayList<>();
        if (o != null && o.has(key)) for (JsonElement e : o.getAsJsonArray(key)) out.add(e.getAsString());
        return out;
    }

    private static int indexOf(List<String> list, String v) {
        for (int i = 0; i < list.size(); i++) if (list.get(i).equalsIgnoreCase(v)) return i;
        return -1;
    }

    private void openDetail(String uuid) {
        detailUuid = uuid;
        detailPage = 0;
        views.remove("player");
        send(ActionType.GET_PLAYER, uuid, "", "", 0);
        rebuildWidgets();
    }

    // ---- widgets ---------------------------------------------------------------------------------------------

    @Override
    protected void buildContent() {
        switch (tab) {
            case "players" -> {
                if (detailUuid != null) buildDetail();
                else buildPlayers();
            }
            case "staff" -> {
                if (detailUuid != null) buildDetail();
                else buildStaff();
            }
            case "logs" -> buildPager(logsPage, (int) Ui.num(views.get("logs"), "pages"), p -> {
                logsPage = p;
                requestTab();
            });
            case "settings" -> buildSettings();
            default -> { }
        }
    }

    private void buildPager(int page, int pages, java.util.function.IntConsumer go) {
        int y = cy + ch - 18;
        int total = Math.max(1, pages);
        btn(Component.literal("<"), cx, y, 20, 14, () -> {
            if (page > 0) go.accept(page - 1);
        });
        btn(Component.literal(">"), cx + 24, y, 20, 14, () -> {
            if (page + 1 < total) go.accept(page + 1);
        });
    }

    private void buildPlayers() {
        edit("players.q", cx, cy, cw - 64, 32, "players.search_hint");
        btn("players.search", cx + cw - 60, cy, 60, 16, () -> {
            playersPage = 0;
            requestTab();
        });
        JsonObject list = views.get("players");
        if (list == null) return;
        JsonArray entries = list.getAsJsonArray("entries");
        int cardW = (cw - 6) / 2;
        for (int i = 0; i < entries.size(); i++) {
            JsonObject e = entries.get(i).getAsJsonObject();
            int x = cx + (i % 2) * (cardW + 6);
            int y = cy + 22 + (i / 2) * 38;
            String uuid = Ui.str(e, "uuid");
            btn("ui.open", x + cardW - 42, y + 18, 38, 14, () -> openDetail(uuid));
        }
        buildPager(playersPage, (int) Ui.num(list, "pages"), p -> {
            playersPage = p;
            requestTab();
        });
    }

    private void buildStaff() {
        edit("staff.add", cx, cy, cw - 64, 32, "staff.add_hint");
        btn("staff.add", cx + cw - 60, cy, 60, 16, () -> send(ActionType.STAFF_ADD, field("staff.add"), "", "", 0));
        JsonObject list = views.get("staff");
        if (list == null) return;
        JsonArray entries = list.getAsJsonArray("entries");
        int pages = Math.max(1, (entries.size() + STAFF_ROWS - 1) / STAFF_ROWS);
        int page = Math.min(staffPage, pages - 1);
        for (int i = page * STAFF_ROWS, row = 0; i < Math.min(entries.size(), (page + 1) * STAFF_ROWS); i++, row++) {
            JsonObject e = entries.get(i).getAsJsonObject();
            String uuid = Ui.str(e, "uuid");
            int y = cy + 22 + row * 22;
            btn("ui.open", cx + cw - 96, y + 3, 44, 14, () -> openDetail(uuid));
            btn(Ui.tr("staff.remove"), cx + cw - 48, y + 3, 48, 14, () -> send(ActionType.STAFF_REMOVE, uuid, "", "", 0));
        }
        buildPager(page, pages, p -> {
            staffPage = p;
            rebuildWidgets();
        });
    }

    private void buildDetail() {
        btn("ui.back", cx, cy, 50, 14, () -> {
            detailUuid = null;
            detailPage = 0;
            requestTab();
            rebuildWidgets();
        });
        JsonObject p = views.get("player");
        if (p == null || !detailUuid.equals(Ui.str(p, "uuid"))) return;
        boolean isOwnerTarget = Ui.bool(p, "isOwner");

        if (detailPage == 1) {
            buildPermissions(p);
            return;
        }
        int x0 = cx + 150, w = cw - 150;
        List<String> jobs = strings(self, "jobs"), ranks = strings(self, "ranks");

        String job = jobs.isEmpty() ? "-" : jobs.get(jobIdx % jobs.size());
        btn(Component.literal(job + "  >"), x0, cy + 24, w - 44, 16, () -> {
            jobIdx++;
            rebuildWidgets();
        }).active = hasPerm("EDIT_JOBS") && !jobs.isEmpty();
        btn("ui.set", x0 + w - 40, cy + 24, 40, 16, () -> send(ActionType.SET_JOB, detailUuid, jobs.get(jobIdx % jobs.size()), "", 0))
                .active = hasPerm("EDIT_JOBS") && !jobs.isEmpty();

        String rank = ranks.isEmpty() ? "-" : ranks.get(rankIdx % ranks.size());
        btn(Component.literal(rank + "  >"), x0, cy + 48, w - 44, 16, () -> {
            rankIdx++;
            rebuildWidgets();
        }).active = hasPerm("EDIT_RANKS") && !ranks.isEmpty();
        btn("ui.set", x0 + w - 40, cy + 48, 40, 16, () -> send(ActionType.SET_RANK, detailUuid, ranks.get(rankIdx % ranks.size()), "", 0))
                .active = hasPerm("EDIT_RANKS") && !ranks.isEmpty();

        edit("d.level", x0, cy + 72, w - 44, 5, "detail.level_hint");
        btn("ui.set", x0 + w - 40, cy + 72, 40, 16, () -> send(ActionType.SET_LEVEL, detailUuid, "", "", Math.max(0, parseLong(field("d.level")))))
                .active = hasPerm("EDIT_RANKS");

        edit("d.amount", x0, cy + 96, 70, 12, "detail.amount_hint");
        edit("d.reason", x0 + 74, cy + 96, w - 74, 60, "detail.reason_hint");
        int bw = (w - 8) / 3;
        boolean canBal = hasPerm("EDIT_BALANCE");
        btn("bal.add", x0, cy + 118, bw, 16, () -> send(ActionType.BAL_ADD, detailUuid, field("d.reason"), "", parseLong(field("d.amount")))).active = canBal;
        btn("bal.remove", x0 + bw + 4, cy + 118, bw, 16, () -> send(ActionType.BAL_REMOVE, detailUuid, field("d.reason"), "", parseLong(field("d.amount")))).active = canBal;
        btn("bal.set", x0 + 2 * (bw + 4), cy + 118, bw, 16, () -> send(ActionType.BAL_SET, detailUuid, field("d.reason"), "", parseLong(field("d.amount")))).active = canBal;

        if (hasPerm("MANAGE_STAFF") && !isOwnerTarget) {
            boolean staff = Ui.bool(p, "isStaff");
            btn(staff ? Ui.tr("staff.remove") : Ui.tr("staff.make"), x0, cy + 144, (w - 4) / 2, 16,
                    () -> send(staff ? ActionType.STAFF_REMOVE : ActionType.STAFF_ADD, detailUuid, "", "", 0));
            btn("detail.permissions", x0 + (w - 4) / 2 + 4, cy + 144, (w - 4) / 2, 16, () -> {
                detailPage = 1;
                rebuildWidgets();
            }).active = staff;
        }
    }

    private void buildPermissions(JsonObject p) {
        int w = (cw - 4) / 2;
        List<String> held = strings(p, "perms");
        Permission[] all = Permission.values();
        for (int i = 0; i < all.length; i++) {
            Permission perm = all[i];
            boolean on = held.contains(perm.name());
            int x = cx + (i % 2) * (w + 4);
            int y = cy + 40 + (i / 2) * 20;
            Component label = Component.literal(on ? "[ON]  " : "[OFF] ").append(Ui.tr("permission." + perm.name().toLowerCase()));
            btn(label, x, y, w, 16, () -> send(on ? ActionType.PERM_REVOKE : ActionType.PERM_GRANT, detailUuid, perm.name(), "", 0))
                    .active = hasPerm("MANAGE_STAFF") && hasPerm(perm.name()) && !Ui.bool(p, "isOwner");
        }
        btn("ui.back", cx, cy + 130, 60, 14, () -> {
            detailPage = 0;
            rebuildWidgets();
        });
    }

    private void buildSettings() {
        JsonObject s = views.get("settings");
        String[] keys = {"cityName", "currencySymbol", "startingBalance", "maxBalance", "maxLevel", "jobs", "ranks"};
        int ex = cx + 104, ew = cw - 104 - 46;
        for (int i = 0; i < keys.length; i++) {
            String k = keys[i];
            int y = cy + i * 20;
            edit("set." + k, ex, y, ew, k.equals("jobs") || k.equals("ranks") ? 300 : 32, null);
            btn("ui.save", cx + cw - 42, y, 42, 16, () -> send(ActionType.SETTINGS_SET, "", k, field("set." + k), 0));
        }
        if (s == null) return;
        String[] toggles = {"allowTransfers", "giveTabletOnFirstJoin"};
        for (int i = 0; i < toggles.length; i++) {
            String k = toggles[i];
            boolean on = Ui.bool(s, k);
            int y = cy + (keys.length + i) * 20;
            btn(on ? Ui.tr("ui.on") : Ui.tr("ui.off"), ex, y, 60, 16, () -> send(ActionType.SETTINGS_SET, "", k, on ? "false" : "true", 0));
        }
    }

    // ---- drawing -----------------------------------------------------------------------------------------------

    @Override
    protected void renderContent(GuiGraphics g, int mouseX, int mouseY) {
        switch (tab) {
            case "players" -> {
                if (detailUuid != null) renderDetail(g);
                else renderPlayers(g);
            }
            case "staff" -> {
                if (detailUuid != null) renderDetail(g);
                else renderStaff(g);
            }
            case "stats" -> renderStats(g);
            case "logs" -> renderLogs(g);
            case "settings" -> renderSettings(g);
            default -> renderDashboard(g);
        }
    }

    private void tiles(GuiGraphics g, JsonObject st, int y0) {
        int gap = 6, w = (cw - gap * 2) / 3, h = 34;
        String cur = Ui.str(st, "currency");
        String[][] t = {
                {"stat.players", Ui.number(Ui.num(st, "totalPlayers"))},
                {"stat.online", Ui.number(Ui.num(st, "onlinePlayers"))},
                {"stat.staff", Ui.number(Ui.num(st, "staffCount"))},
                {"stat.money", Ui.money(Ui.num(st, "totalMoney"), cur)},
                {"stat.average", Ui.money(Ui.num(st, "averageMoney"), cur)},
                {"stat.transactions", Ui.number(Ui.num(st, "transactionCount"))},
        };
        for (int i = 0; i < t.length; i++) {
            statCard(g, cx + (i % 3) * (w + gap), y0 + (i / 3) * (h + gap), w, h, Ui.tr(t[i][0]).getString(), t[i][1], i == 3 ? Ui.GOLD : Ui.TEXT);
        }
    }

    private void renderDashboard(GuiGraphics g) {
        Ui.text(g, font, Ui.tr("dashboard.welcome", Ui.str(self, "name")), cx, cy, Ui.GOLD);
        Ui.text(g, font, Ui.str(self, "cityName") + (Ui.bool(self, "isOwner") ? "  |  " + Ui.tr("dashboard.owner").getString() : "  |  " + Ui.tr("dashboard.staff").getString()), cx, cy + 11, Ui.MUTED);
        JsonObject st = views.get("stats");
        if (hasPerm("VIEW_STATS")) {
            if (st != null) tiles(g, st, cy + 26);
            else Ui.text(g, font, Ui.tr("ui.loading"), cx, cy + 30, Ui.MUTED);
        }
        int y = cy + 26 + (hasPerm("VIEW_STATS") ? 84 : 0);
        Ui.text(g, font, Ui.tr("dashboard.recent"), cx, y, Ui.GOLD);
        Ui.rect(g, cx, y + 10, cw, 1, Ui.GOLD_DIM);
        JsonObject logs = views.get("logs");
        if (!hasPerm("VIEW_LOGS")) {
            Ui.text(g, font, Ui.tr("msg.no_permission"), cx, y + 16, Ui.MUTED);
        } else if (logs != null) {
            int n = 0;
            for (JsonElement el : logs.getAsJsonArray("entries")) {
                if (n++ >= 5) break;
                drawLogLine(g, el.getAsJsonObject(), y + 15 + (n - 1) * 11);
            }
        }
    }

    private void drawLogLine(GuiGraphics g, JsonObject e, int y) {
        String action = Ui.str(e, "action");
        Ui.sequence(g, font, cx, y, cx + cw,
                Ui.dateShort(Ui.num(e, "time")) + "  ", Ui.MUTED,
                Ui.str(e, "actor") + "  ", Ui.TEXT,
                action + "  ", action.startsWith("DENIED") ? Ui.BAD : Ui.GOLD,
                Ui.str(e, "target") + "  ", Ui.TEXT,
                Ui.str(e, "details"), Ui.MUTED);
    }

    private void renderPlayers(GuiGraphics g) {
        JsonObject list = views.get("players");
        if (list == null) {
            Ui.text(g, font, Ui.tr("ui.loading"), cx, cy + 26, Ui.MUTED);
            return;
        }
        JsonArray entries = list.getAsJsonArray("entries");
        int cardW = (cw - 6) / 2;
        for (int i = 0; i < entries.size(); i++) {
            JsonObject e = entries.get(i).getAsJsonObject();
            int x = cx + (i % 2) * (cardW + 6);
            int y = cy + 22 + (i / 2) * 38;
            Ui.card(g, x, y, cardW, 34);
            Ui.rect(g, x + 6, y + 6, 5, 5, Ui.bool(e, "online") ? Ui.GOOD : Ui.MUTED);
            Ui.text(g, font, Ui.fit(font, Ui.str(e, "name"), cardW - 24), x + 15, y + 4, Ui.bool(e, "staff") ? Ui.GOLD : Ui.TEXT);
            Ui.text(g, font, Ui.fit(font, Ui.str(e, "job") + " | " + Ui.str(e, "rank") + " | L" + Ui.num(e, "level"), cardW - 10), x + 6, y + 15, Ui.MUTED);
            Ui.text(g, font, Ui.money(Ui.num(e, "balance"), currency()), x + 6, y + 24, Ui.GOLD_DIM);
        }
        Ui.text(g, font, (Ui.num(list, "page") + 1) + " / " + Ui.num(list, "pages") + "   (" + Ui.num(list, "total") + ")", cx + 50, cy + ch - 15, Ui.MUTED);
    }

    private void renderStaff(GuiGraphics g) {
        JsonObject list = views.get("staff");
        if (list == null) {
            Ui.text(g, font, Ui.tr("ui.loading"), cx, cy + 26, Ui.MUTED);
            return;
        }
        JsonArray entries = list.getAsJsonArray("entries");
        if (entries.isEmpty()) Ui.text(g, font, Ui.tr("staff.none"), cx, cy + 26, Ui.MUTED);
        int pages = Math.max(1, (entries.size() + STAFF_ROWS - 1) / STAFF_ROWS);
        int page = Math.min(staffPage, pages - 1);
        for (int i = page * STAFF_ROWS, row = 0; i < Math.min(entries.size(), (page + 1) * STAFF_ROWS); i++, row++) {
            JsonObject e = entries.get(i).getAsJsonObject();
            int y = cy + 22 + row * 22;
            Ui.card(g, cx, y, cw, 20);
            Ui.rect(g, cx + 6, y + 7, 5, 5, Ui.bool(e, "online") ? Ui.GOOD : Ui.MUTED);
            Ui.text(g, font, Ui.str(e, "name"), cx + 15, y + 6, Ui.GOLD);
            Ui.text(g, font, Ui.tr("staff.perm_count", e.getAsJsonArray("perms").size()), cx + 100, y + 6, Ui.MUTED);
        }
        Ui.text(g, font, (page + 1) + " / " + pages, cx + 50, cy + ch - 15, Ui.MUTED);
    }

    private void renderDetail(GuiGraphics g) {
        JsonObject p = views.get("player");
        if (p == null || !detailUuid.equals(Ui.str(p, "uuid"))) {
            Ui.text(g, font, Ui.tr("ui.loading"), cx + 56, cy + 3, Ui.MUTED);
            return;
        }
        String name = Ui.str(p, "name");
        Ui.text(g, font, name, cx + 56, cy + 3, Ui.GOLD);
        if (detailPage == 1) {
            Ui.text(g, font, Ui.tr("detail.permissions_title", name), cx, cy + 22, Ui.TEXT);
            Ui.text(g, font, Ui.tr("detail.permissions_note"), cx, cy + 156, Ui.MUTED);
            return;
        }
        avatar(g, cx, cy + 20, 36, name);
        int y = cy + 62;
        JsonObject rp = Ui.obj(p, "rp");
        String[][] lines = {
                {"detail.status", Ui.tr(Ui.bool(p, "online") ? "detail.online" : "detail.offline").getString()},
                {"detail.job", Ui.str(p, "job")},
                {"detail.rank", Ui.str(p, "rank") + "  (L" + Ui.num(p, "level") + ")"},
                {"detail.balance", Ui.money(Ui.num(p, "balance"), currency())},
                {"detail.playtime", Ui.duration(Ui.num(p, "playSeconds"))},
                {"detail.kd", Ui.num(p, "kills") + " / " + Ui.num(p, "mobKills") + " / " + Ui.num(p, "deaths")},
                {"detail.rp_name", Ui.str(rp, "fullName").isEmpty() ? "-" : Ui.str(rp, "fullName")},
                {"detail.last_seen", Ui.dateShort(Ui.num(p, "lastSeen"))},
        };
        for (String[] l : lines) {
            Ui.text(g, font, Ui.fit(font, Ui.tr(l[0]).getString() + ": " + l[1], 144), cx, y, Ui.TEXT);
            y += 11;
        }
        int x0 = cx + 150;
        Ui.text(g, font, Ui.tr("detail.job"), x0, cy + 15, Ui.MUTED);
        Ui.text(g, font, Ui.tr("detail.rank"), x0, cy + 39, Ui.MUTED);
        Ui.text(g, font, Ui.tr("detail.level"), x0, cy + 63, Ui.MUTED);
        Ui.text(g, font, Ui.tr("detail.balance"), x0, cy + 87, Ui.MUTED);
        if (Ui.bool(p, "isOwner")) Ui.text(g, font, Ui.tr("msg.target_is_owner"), x0, cy + 166, Ui.BAD);
    }

    private void renderStats(GuiGraphics g) {
        JsonObject st = views.get("stats");
        if (st == null) {
            Ui.text(g, font, Ui.tr("ui.loading"), cx, cy, Ui.MUTED);
            return;
        }
        tiles(g, st, cy);
        int colW = (cw - 8) / 2;
        int y = cy + 84;
        Ui.text(g, font, Ui.tr("stat.richest"), cx, y, Ui.GOLD);
        Ui.text(g, font, Ui.tr("stat.jobs"), cx + colW + 8, y, Ui.GOLD);
        Ui.rect(g, cx, y + 10, colW, 1, Ui.GOLD_DIM);
        Ui.rect(g, cx + colW + 8, y + 10, colW, 1, Ui.GOLD_DIM);
        JsonArray rich = st.getAsJsonArray("richest");
        for (int i = 0; i < Math.min(6, rich.size()); i++) {
            JsonObject e = rich.get(i).getAsJsonObject();
            Ui.text(g, font, (i + 1) + ". " + Ui.fit(font, Ui.str(e, "name"), colW - 70), cx, y + 14 + i * 12, Ui.TEXT);
            Ui.right(g, font, Ui.number(Ui.num(e, "balance")), cx + colW, y + 14 + i * 12, Ui.GOLD);
        }
        JsonArray jobs = st.getAsJsonArray("jobs");
        long max = 1;
        for (JsonElement el : jobs) max = Math.max(max, Ui.num(el.getAsJsonObject(), "count"));
        for (int i = 0; i < Math.min(6, jobs.size()); i++) {
            JsonObject e = jobs.get(i).getAsJsonObject();
            int yy = y + 14 + i * 12;
            int bx = cx + colW + 8;
            Ui.text(g, font, Ui.fit(font, Ui.str(e, "job"), 70), bx, yy, Ui.TEXT);
            int bw = (int) ((colW - 100) * (Ui.num(e, "count") / (double) max));
            Ui.rect(g, bx + 74, yy + 1, Math.max(2, bw), 7, Ui.RED);
            Ui.text(g, font, Ui.number(Ui.num(e, "count")), bx + 78 + Math.max(2, bw), yy, Ui.MUTED);
        }
    }

    private void renderLogs(GuiGraphics g) {
        JsonObject logs = views.get("logs");
        if (logs == null) {
            Ui.text(g, font, Ui.tr("ui.loading"), cx, cy, Ui.MUTED);
            return;
        }
        JsonArray entries = logs.getAsJsonArray("entries");
        if (entries.isEmpty()) Ui.text(g, font, Ui.tr("logs.none"), cx, cy, Ui.MUTED);
        for (int i = 0; i < entries.size(); i++) drawLogLine(g, entries.get(i).getAsJsonObject(), cy + i * 13);
        Ui.text(g, font, (Ui.num(logs, "page") + 1) + " / " + Ui.num(logs, "pages") + "   (" + Ui.num(logs, "total") + ")", cx + 50, cy + ch - 15, Ui.MUTED);
    }

    private void renderSettings(GuiGraphics g) {
        String[] keys = {"cityName", "currencySymbol", "startingBalance", "maxBalance", "maxLevel", "jobs", "ranks", "allowTransfers", "giveTabletOnFirstJoin"};
        for (int i = 0; i < keys.length; i++) {
            Ui.text(g, font, Ui.fit(font, Ui.tr("setting." + keys[i]).getString(), 100), cx, cy + i * 20 + 4, Ui.TEXT);
        }
        if (views.get("settings") == null) Ui.text(g, font, Ui.tr("ui.loading"), cx + 104, cy + 9 * 20, Ui.MUTED);
        Ui.text(g, font, Ui.tr("settings.owner_note"), cx, cy + ch - 12, Ui.MUTED);
    }
}
