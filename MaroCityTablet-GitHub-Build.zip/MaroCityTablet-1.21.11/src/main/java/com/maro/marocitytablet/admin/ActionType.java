package com.maro.marocitytablet.admin;

/**
 * Every request a tablet can send to the server. The ordinal is NOT used on the wire for trust:
 * the network layer maps unknown values to {@link #INVALID}, which the server ignores.
 */
public enum ActionType {
    INVALID,
    SELF,
    LIST_PLAYERS,
    GET_PLAYER,
    SET_JOB,
    SET_RANK,
    SET_LEVEL,
    BAL_ADD,
    BAL_REMOVE,
    BAL_SET,
    TRANSFER,
    STAFF_LIST,
    STAFF_ADD,
    STAFF_REMOVE,
    PERM_GRANT,
    PERM_REVOKE,
    LOGS,
    STATS,
    SETTINGS_GET,
    SETTINGS_SET,
    RP_UPDATE,
    MY_TX;

    public static ActionType fromOrdinal(int i) {
        ActionType[] v = values();
        return i >= 0 && i < v.length ? v[i] : INVALID;
    }
}
