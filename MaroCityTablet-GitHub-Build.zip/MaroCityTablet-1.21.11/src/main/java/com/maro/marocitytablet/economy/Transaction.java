package com.maro.marocitytablet.economy;

/** One row of the transaction ledger. {@code type} is ADD, REMOVE, SET, TRANSFER or STARTING. */
public final class Transaction {
    public long id;
    public long time;
    public String type;
    public String fromUuid;
    public String fromName;
    public String toUuid;
    public String toName;
    public long amount;
    /** Balance of the receiving (or affected) player after the operation. */
    public long balanceAfter;
    public String reason;
    public String actorUuid;
    public String actorName;
}
