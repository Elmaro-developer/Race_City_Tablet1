package com.maro.marocitytablet.admin;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.maro.marocitytablet.config.ServerSettings;
import com.maro.marocitytablet.economy.Transaction;
import com.maro.marocitytablet.permissions.Permission;
import com.maro.marocitytablet.permissions.PermissionManager;
import com.maro.marocitytablet.players.PlayerRecord;
import com.maro.marocitytablet.players.PlayerService;
import com.maro.marocitytablet.storage.DataStore;
import com.maro.marocitytablet.config.SettingsManager;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Builds the JSON documents that are sent to tablets. Nothing secret is ever included: no owner UUIDs,
 * no file paths, no other player's permissions unless the viewer is allowed to manage staff.
 */
public final class ViewBuilder {
    public static final int PAGE_PLAYERS = 8;
    public static final int PAGE_LOGS = 12;
    public static final int PAGE_TX = 8;

    private final SettingsManager settings;
    private final DataStore store;
    private final PermissionManager perms;
    private final PlayerService players;
    private final OnlineInfo online;

    public ViewBuilder(SettingsManager settings, DataStore store, PermissionManager perms, PlayerService players, OnlineInfo online) {
        this.settings = settings;
        this.store = store;
        this.perms = perms;
        this.players = players;
        this.online = online;
    }

    private static JsonArray strings(List<String> list) {
        JsonArray a = new JsonArray();
        list.forEach(a::add);
        return a;
    }

    private static void core(JsonObject o, PlayerRecord r) {
        o.addProperty("uuid", r.uuid);
        o.addProperty("name", r.name);
        o.addProperty("job", r.job);
        o.addProperty("rank", r.rank);
        o.addProperty("level", r.level);
        o.addProperty("balance", r.balance);
        o.addProperty("playSeconds", r.playSeconds);
        o.addProperty("kills", r.kills);
        o.addProperty("mobKills", r.mobKills);
        o.addProperty("deaths", r.deaths);
        o.addProperty("advancements", r.advancements);
        o.addProperty("firstJoin", r.firstJoin);
        o.addProperty("lastSeen", r.lastSeen);
        JsonObject rp = new JsonObject();
        rp.addProperty("fullName", r.rp.fullName);
        rp.addProperty("age", r.rp.age);
        rp.addProperty("gender", r.rp.gender);
        rp.addProperty("phone", r.rp.phone);
        rp.addProperty("bio", r.rp.bio);
        o.add("rp", rp);
        JsonArray hist = new JsonArray();
        // newest first, last 40
        for (int i = r.history.size() - 1, c = 0; i >= 0 && c < 40; i--, c++) {
            PlayerRecord.HistoryEntry h = r.history.get(i);
            JsonObject e = new JsonObject();
            e.addProperty("time", h.time);
            e.addProperty("type", h.type);
            e.addProperty("from", h.from);
            e.addProperty("to", h.to);
            e.addProperty("by", h.by);
            hist.add(e);
        }
        o.add("history", hist);
    }

    /** The viewer's own profile plus the data the tablet needs to decide which tabs to show. */
    public JsonObject self(PlayerRecord r) {
        JsonObject o = new JsonObject();
        core(o, r);
        ServerSettings s = settings.get();
        UUID id = UUID.fromString(r.uuid);
        o.addProperty("isOwner", perms.isOwner(id));
        o.addProperty("isStaff", r.staff);
        JsonArray p = new JsonArray();
        for (Permission perm : perms.effective(id)) p.add(perm.name());
        o.add("perms", p);
        o.addProperty("cityName", s.cityName);
        o.addProperty("currency", s.currencySymbol);
        o.addProperty("maxLevel", s.maxLevel);
        o.addProperty("allowTransfers", s.allowTransfers);
        o.add("jobs", strings(s.jobs));
        o.add("ranks", strings(s.ranks));
        return o;
    }

    /** Another player's profile, as seen by an administrator. */
    public JsonObject player(PlayerRecord r, boolean viewerCanSeePermissions) {
        JsonObject o = new JsonObject();
        core(o, r);
        o.addProperty("online", online.isOnline(UUID.fromString(r.uuid)));
        o.addProperty("isOwner", perms.isOwner(r));
        o.addProperty("isStaff", r.staff);
        JsonArray p = new JsonArray();
        if (viewerCanSeePermissions) r.permissions.forEach(p::add);
        o.add("perms", p);
        return o;
    }

    public JsonObject playerList(String query, int page) {
        List<PlayerRecord> all = players.search(query);
        int pages = Math.max(1, (all.size() + PAGE_PLAYERS - 1) / PAGE_PLAYERS);
        int pg = Math.max(0, Math.min(page, pages - 1));
        JsonObject o = new JsonObject();
        o.addProperty("query", query == null ? "" : query);
        o.addProperty("page", pg);
        o.addProperty("pages", pages);
        o.addProperty("total", all.size());
        JsonArray arr = new JsonArray();
        for (int i = pg * PAGE_PLAYERS; i < Math.min(all.size(), (pg + 1) * PAGE_PLAYERS); i++) {
            PlayerRecord r = all.get(i);
            JsonObject e = new JsonObject();
            e.addProperty("uuid", r.uuid);
            e.addProperty("name", r.name);
            e.addProperty("job", r.job);
            e.addProperty("rank", r.rank);
            e.addProperty("level", r.level);
            e.addProperty("balance", r.balance);
            e.addProperty("online", online.isOnline(UUID.fromString(r.uuid)));
            e.addProperty("staff", r.staff);
            arr.add(e);
        }
        o.add("entries", arr);
        return o;
    }

    public JsonObject staffList() {
        JsonObject o = new JsonObject();
        JsonArray arr = new JsonArray();
        List<PlayerRecord> staff = new ArrayList<>();
        for (PlayerRecord r : store.players().values()) if (r.staff) staff.add(r);
        staff.sort(Comparator.comparing(r -> r.name.toLowerCase()));
        for (PlayerRecord r : staff) {
            JsonObject e = new JsonObject();
            e.addProperty("uuid", r.uuid);
            e.addProperty("name", r.name);
            e.addProperty("online", online.isOnline(UUID.fromString(r.uuid)));
            e.add("perms", strings(new ArrayList<>(r.permissions)));
            arr.add(e);
        }
        o.add("entries", arr);
        return o;
    }

    public JsonObject stats() {
        JsonObject o = new JsonObject();
        List<PlayerRecord> all = new ArrayList<>(store.players().values());
        long total = 0;
        int staff = 0;
        Map<String, Integer> jobs = new LinkedHashMap<>();
        for (PlayerRecord r : all) {
            total += r.balance;
            if (r.staff) staff++;
            jobs.merge(r.job, 1, Integer::sum);
        }
        o.addProperty("totalPlayers", all.size());
        o.addProperty("onlinePlayers", online.onlineCount());
        o.addProperty("staffCount", staff);
        o.addProperty("totalMoney", total);
        o.addProperty("averageMoney", all.isEmpty() ? 0 : total / all.size());
        o.addProperty("transactionCount", store.transactions().size());
        o.addProperty("currency", settings.get().currencySymbol);

        all.sort(Comparator.comparingLong((PlayerRecord r) -> r.balance).reversed());
        JsonArray rich = new JsonArray();
        for (int i = 0; i < Math.min(8, all.size()); i++) {
            JsonObject e = new JsonObject();
            e.addProperty("name", all.get(i).name);
            e.addProperty("balance", all.get(i).balance);
            rich.add(e);
        }
        o.add("richest", rich);

        JsonArray jobArr = new JsonArray();
        jobs.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(10)
                .forEach(en -> {
                    JsonObject e = new JsonObject();
                    e.addProperty("job", en.getKey());
                    e.addProperty("count", en.getValue());
                    jobArr.add(e);
                });
        o.add("jobs", jobArr);
        return o;
    }

    public JsonObject logs(int page) {
        List<AdminLogEntry> log = store.adminLog();
        int pages = Math.max(1, (log.size() + PAGE_LOGS - 1) / PAGE_LOGS);
        int pg = Math.max(0, Math.min(page, pages - 1));
        JsonObject o = new JsonObject();
        o.addProperty("page", pg);
        o.addProperty("pages", pages);
        o.addProperty("total", log.size());
        JsonArray arr = new JsonArray();
        // newest first
        int start = log.size() - 1 - pg * PAGE_LOGS;
        for (int i = start, c = 0; i >= 0 && c < PAGE_LOGS; i--, c++) {
            AdminLogEntry l = log.get(i);
            JsonObject e = new JsonObject();
            e.addProperty("time", l.time);
            e.addProperty("actor", l.actorName);
            e.addProperty("action", l.action);
            e.addProperty("target", l.targetName == null ? "" : l.targetName);
            e.addProperty("details", l.details == null ? "" : l.details);
            arr.add(e);
        }
        o.add("entries", arr);
        return o;
    }

    public JsonObject myTransactions(UUID viewer, int page) {
        String id = viewer.toString();
        List<Transaction> mine = new ArrayList<>();
        List<Transaction> all = store.transactions();
        for (int i = all.size() - 1; i >= 0; i--) {
            Transaction t = all.get(i);
            if (id.equals(t.fromUuid) || id.equals(t.toUuid)) mine.add(t);
        }
        int pages = Math.max(1, (mine.size() + PAGE_TX - 1) / PAGE_TX);
        int pg = Math.max(0, Math.min(page, pages - 1));
        JsonObject o = new JsonObject();
        o.addProperty("page", pg);
        o.addProperty("pages", pages);
        JsonArray arr = new JsonArray();
        for (int i = pg * PAGE_TX; i < Math.min(mine.size(), (pg + 1) * PAGE_TX); i++) {
            Transaction t = mine.get(i);
            JsonObject e = new JsonObject();
            e.addProperty("time", t.time);
            e.addProperty("type", t.type);
            e.addProperty("from", t.fromName == null ? "" : t.fromName);
            e.addProperty("to", t.toName == null ? "" : t.toName);
            e.addProperty("amount", t.amount);
            e.addProperty("incoming", id.equals(t.toUuid));
            e.addProperty("note", t.reason == null ? "" : t.reason);
            arr.add(e);
        }
        o.add("entries", arr);
        return o;
    }

    /** Server settings that an administrator with SERVER_MANAGEMENT may edit. Owner UUIDs are deliberately absent. */
    public JsonObject settingsView() {
        ServerSettings s = settings.get();
        JsonObject o = new JsonObject();
        o.addProperty("cityName", s.cityName);
        o.addProperty("currencySymbol", s.currencySymbol);
        o.addProperty("startingBalance", s.startingBalance);
        o.addProperty("maxBalance", s.maxBalance);
        o.addProperty("allowTransfers", s.allowTransfers);
        o.addProperty("giveTabletOnFirstJoin", s.giveTabletOnFirstJoin);
        o.addProperty("maxLevel", s.maxLevel);
        o.addProperty("jobs", String.join(", ", s.jobs));
        o.addProperty("ranks", String.join(", ", s.ranks));
        return o;
    }

    public JsonObject toast(OpResult r) {
        JsonObject o = new JsonObject();
        o.addProperty("ok", r.ok());
        o.addProperty("key", r.key());
        o.add("args", strings(r.args()));
        return o;
    }
}
