package com.maro.marocitytablet.admin;

import java.util.List;

/** Outcome of a server-side operation. {@code key} is a translation key resolved on the client. */
public record OpResult(boolean ok, String key, List<String> args) {
    public static OpResult ok(String key, String... args) {
        return new OpResult(true, key, List.of(args));
    }

    public static OpResult fail(String key, String... args) {
        return new OpResult(false, key, List.of(args));
    }
}
