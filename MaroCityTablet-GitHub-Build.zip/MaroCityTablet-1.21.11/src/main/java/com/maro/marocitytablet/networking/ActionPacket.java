package com.maro.marocitytablet.networking;

import com.maro.marocitytablet.admin.ActionType;
import com.maro.marocitytablet.main.TabletServer;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.network.CustomPayloadEvent;

/**
 * Client to server request. Carries only intent (an action plus arguments). The server decides everything:
 * what the sender may do is looked up from server-side data, never taken from this packet.
 */
public record ActionPacket(ActionType action, String target, String a, String b, long n) {
    public static final int MAX_TARGET = 64;
    public static final int MAX_ARG = 400;

    public static final StreamCodec<RegistryFriendlyByteBuf, ActionPacket> STREAM_CODEC =
            StreamCodec.ofMember(ActionPacket::encode, ActionPacket::decode);

    public static void encode(ActionPacket p, RegistryFriendlyByteBuf buf) {
        buf.writeVarInt(p.action.ordinal());
        buf.writeUtf(p.target, MAX_TARGET);
        buf.writeUtf(p.a, MAX_ARG);
        buf.writeUtf(p.b, MAX_ARG);
        buf.writeLong(p.n);
    }

    public static ActionPacket decode(RegistryFriendlyByteBuf buf) {
        ActionType type = ActionType.fromOrdinal(buf.readVarInt());
        String target = buf.readUtf(MAX_TARGET);
        String a = buf.readUtf(MAX_ARG);
        String b = buf.readUtf(MAX_ARG);
        long n = buf.readLong();
        return new ActionPacket(type, target, a, b, n);
    }

    /** Runs on the server main thread (addMain). */
    public static void handle(ActionPacket packet, CustomPayloadEvent.Context ctx) {
        ServerPlayer sender = ctx.getSender();
        if (sender == null) return;
        TabletServer.handleAction(sender, packet);
    }
}
