package com.maro.marocitytablet.permissions;

import com.maro.marocitytablet.admin.OpResult;
import com.maro.marocitytablet.config.SettingsManager;
import com.maro.marocitytablet.players.PlayerRecord;
import com.maro.marocitytablet.storage.DataStore;

import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;

/**
 * Independent permission system. Rules enforced here (and therefore on the server only):
 * <ul>
 *   <li>The owner (UUID from server settings) holds everything and can never be modified by anyone else.</li>
 *   <li>Staff hold exactly the permissions explicitly granted to them.</li>
 *   <li>MANAGE_STAFF is required to add/remove staff or change permissions.</li>
 *   <li>A staff member can only grant or revoke permissions that they hold themselves.</li>
 *   <li>MANAGE_STAFF and SERVER_MANAGEMENT can only be granted/revoked, and their holders only removed, by the owner.</li>
 * </ul>
 */
public final class PermissionManager {
    private final SettingsManager settings;
    private final DataStore store;

    public PermissionManager(SettingsManager settings, DataStore store) {
        this.settings = settings;
        this.store = store;
    }

    public boolean isOwner(UUID uuid) {
        return settings.isOwner(uuid);
    }

    public boolean isOwner(PlayerRecord r) {
        try {
            return r != null && settings.isOwner(UUID.fromString(r.uuid));
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    /** Owner or staff member: allowed to open the Owner Tablet at all. */
    public boolean isAdmin(UUID uuid) {
        if (isOwner(uuid)) return true;
        PlayerRecord r = store.get(uuid);
        return r != null && r.staff;
    }

    public boolean has(UUID uuid, Permission p) {
        if (isOwner(uuid)) return true;
        PlayerRecord r = store.get(uuid);
        return r != null && r.staff && r.permissions.contains(p.name());
    }

    public Set<Permission> effective(UUID uuid) {
        if (isOwner(uuid)) return EnumSet.allOf(Permission.class);
        Set<Permission> out = EnumSet.noneOf(Permission.class);
        PlayerRecord r = store.get(uuid);
        if (r != null && r.staff) {
            for (String s : r.permissions) Permission.parse(s).ifPresent(out::add);
        }
        return out;
    }

    // ---- staff management ---------------------------------------------------------------------------------

    public OpResult addStaff(UUID actor, PlayerRecord target) {
        if (!has(actor, Permission.MANAGE_STAFF)) return OpResult.fail("msg.no_permission");
        if (isOwner(target)) return OpResult.fail("msg.target_is_owner");
        if (target.staff) return OpResult.fail("msg.already_staff", target.name);
        target.staff = true;
        target.permissions.clear();
        store.markPlayersDirty();
        return OpResult.ok("msg.staff_added", target.name);
    }

    public OpResult removeStaff(UUID actor, PlayerRecord target) {
        if (!has(actor, Permission.MANAGE_STAFF)) return OpResult.fail("msg.no_permission");
        if (isOwner(target)) return OpResult.fail("msg.target_is_owner");
        if (!target.staff) return OpResult.fail("msg.not_staff", target.name);
        boolean actorIsOwner = isOwner(actor);
        boolean privileged = target.permissions.contains(Permission.MANAGE_STAFF.name())
                || target.permissions.contains(Permission.SERVER_MANAGEMENT.name());
        if (privileged && !actorIsOwner) return OpResult.fail("msg.owner_only");
        target.staff = false;
        target.permissions.clear();
        store.markPlayersDirty();
        return OpResult.ok("msg.staff_removed", target.name);
    }

    public OpResult grant(UUID actor, PlayerRecord target, Permission p) {
        OpResult pre = checkPermissionEdit(actor, target, p);
        if (pre != null) return pre;
        if (!target.permissions.add(p.name())) return OpResult.ok("msg.perm_already", target.name);
        store.markPlayersDirty();
        return OpResult.ok("msg.perm_granted", p.name(), target.name);
    }

    public OpResult revoke(UUID actor, PlayerRecord target, Permission p) {
        OpResult pre = checkPermissionEdit(actor, target, p);
        if (pre != null) return pre;
        if (!target.permissions.remove(p.name())) return OpResult.ok("msg.perm_not_held", target.name);
        store.markPlayersDirty();
        return OpResult.ok("msg.perm_revoked", p.name(), target.name);
    }

    /** Shared checks for grant/revoke. Returns a failure, or null when the edit is allowed. */
    private OpResult checkPermissionEdit(UUID actor, PlayerRecord target, Permission p) {
        if (!has(actor, Permission.MANAGE_STAFF)) return OpResult.fail("msg.no_permission");
        if (isOwner(target)) return OpResult.fail("msg.target_is_owner");
        if (!target.staff) return OpResult.fail("msg.not_staff", target.name);
        boolean actorIsOwner = isOwner(actor);
        if (p.ownerOnlyGrant() && !actorIsOwner) return OpResult.fail("msg.owner_only");
        if (!has(actor, p)) return OpResult.fail("msg.cannot_grant_unheld");
        return null;
    }
}
