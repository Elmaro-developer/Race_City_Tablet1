package com.maro.marocitytablet.main;

import com.maro.marocitytablet.admin.ActionType;
import com.maro.marocitytablet.admin.TabletCore;
import com.maro.marocitytablet.players.PlayerRecord;
import com.maro.marocitytablet.registry.ModItems;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.fml.loading.FMLEnvironment;

import java.util.Locale;

/**
 * Chat commands. They deliberately do NOT use vanilla operator levels: every check goes through the mod's own
 * permission system (owner UUID / staff permissions) so that being an OP never grants tablet powers.
 * <ul>
 *   <li>/balance, /pay &lt;player&gt; &lt;amount&gt; - for everyone</li>
 *   <li>/marocity tablet - get a Player Tablet if you do not carry one</li>
 *   <li>/marocity give owner - the owner gives themselves an Owner Tablet</li>
 *   <li>/marocity give player &lt;name&gt; - owner or SERVER_MANAGEMENT staff, or the server console</li>
 *   <li>/marocity claimowner - single player only, while no owner is configured</li>
 *   <li>/marocity reload - owner or console; re-reads the settings file</li>
 * </ul>
 */
public final class TabletCommands {
    private TabletCommands() {}

    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();

        d.register(Commands.literal("balance").executes(ctx -> balance(ctx.getSource())));

        d.register(Commands.literal("pay")
                .then(Commands.argument("player", StringArgumentType.word())
                        .then(Commands.argument("amount", LongArgumentType.longArg(1))
                                .executes(ctx -> pay(ctx.getSource(),
                                        StringArgumentType.getString(ctx, "player"),
                                        LongArgumentType.getLong(ctx, "amount"))))));

        d.register(Commands.literal("marocity")
                .then(Commands.literal("tablet").executes(ctx -> giveOwnPlayerTablet(ctx.getSource())))
                .then(Commands.literal("give")
                        .then(Commands.literal("owner").executes(ctx -> giveOwnerTablet(ctx.getSource())))
                        .then(Commands.literal("player")
                                .then(Commands.argument("name", StringArgumentType.word())
                                        .executes(ctx -> givePlayerTablet(ctx.getSource(), StringArgumentType.getString(ctx, "name"))))))
                .then(Commands.literal("claimowner").executes(ctx -> claimOwner(ctx.getSource())))
                .then(Commands.literal("reload").executes(ctx -> reload(ctx.getSource()))));
    }

    private static int fail(CommandSourceStack src, String key) {
        src.sendFailure(Component.translatable("marocitytablet." + key));
        return 0;
    }

    private static int ok(CommandSourceStack src, String key, Object... args) {
        src.sendSuccess(() -> Component.translatable("marocitytablet." + key, args), false);
        return 1;
    }

    private static ServerPlayer player(CommandSourceStack src) {
        return src.getEntity() instanceof ServerPlayer p ? p : null;
    }

    private static int balance(CommandSourceStack src) {
        TabletCore core = TabletServer.core();
        ServerPlayer p = player(src);
        if (core == null || p == null) return fail(src, "msg.players_only");
        PlayerRecord r = core.store.get(p.getUUID());
        if (r == null) return fail(src, "msg.no_profile");
        return ok(src, "msg.balance", String.format(Locale.US, "%,d", r.balance), core.settings.get().currencySymbol);
    }

    private static int pay(CommandSourceStack src, String target, long amount) {
        ServerPlayer p = player(src);
        if (TabletServer.core() == null || p == null) return fail(src, "msg.players_only");
        TabletServer.runAction(p, ActionType.TRANSFER, "", target, "", amount, true);
        return 1;
    }

    private static int giveOwnPlayerTablet(CommandSourceStack src) {
        ServerPlayer p = player(src);
        if (TabletServer.core() == null || p == null) return fail(src, "msg.players_only");
        if (TabletServer.hasItem(p, ModItems.PLAYER_TABLET.get())) return fail(src, "msg.already_have_tablet");
        TabletServer.giveTablet(p, ModItems.PLAYER_TABLET.get());
        return ok(src, "msg.tablet_given");
    }

    private static int giveOwnerTablet(CommandSourceStack src) {
        TabletCore core = TabletServer.core();
        ServerPlayer p = player(src);
        if (core == null || p == null) return fail(src, "msg.players_only");
        if (!core.permissions.isOwner(p.getUUID())) return fail(src, "msg.no_permission");
        if (TabletServer.hasItem(p, ModItems.OWNER_TABLET.get())) return fail(src, "msg.already_have_tablet");
        TabletServer.giveTablet(p, ModItems.OWNER_TABLET.get());
        return ok(src, "msg.tablet_given");
    }

    private static int givePlayerTablet(CommandSourceStack src, String name) {
        TabletCore core = TabletServer.core();
        var server = TabletServer.server();
        if (core == null || server == null) return fail(src, "msg.players_only");
        ServerPlayer caller = player(src);
        if (caller != null && !core.permissions.has(caller.getUUID(), com.maro.marocitytablet.permissions.Permission.SERVER_MANAGEMENT)) {
            return fail(src, "msg.no_permission");
        }
        ServerPlayer target = server.getPlayerList().getPlayerByName(name);
        if (target == null) return fail(src, "msg.player_not_found");
        TabletServer.giveTablet(target, ModItems.PLAYER_TABLET.get());
        return ok(src, "msg.tablet_given");
    }

    /** Single player convenience. On a dedicated server the owner must be written into the settings file. */
    private static int claimOwner(CommandSourceStack src) {
        TabletCore core = TabletServer.core();
        ServerPlayer p = player(src);
        if (core == null || p == null) return fail(src, "msg.players_only");
        if (FMLEnvironment.dist.isDedicatedServer()) return fail(src, "msg.claim_dedicated");
        if (!core.settings.get().ownerUuids.isEmpty()) return fail(src, "msg.claim_taken");
        core.settings.addOwner(p.getUUID());
        return ok(src, "msg.claim_done");
    }

    private static int reload(CommandSourceStack src) {
        TabletCore core = TabletServer.core();
        if (core == null) return fail(src, "msg.players_only");
        ServerPlayer p = player(src);
        if (p != null && !core.permissions.isOwner(p.getUUID())) return fail(src, "msg.no_permission");
        core.settings.load();
        return ok(src, "msg.reloaded");
    }
}
