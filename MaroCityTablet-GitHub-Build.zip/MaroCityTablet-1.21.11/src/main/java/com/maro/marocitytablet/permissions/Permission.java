package com.maro.marocitytablet.permissions;

import java.util.Locale;
import java.util.Optional;

/**
 * Every administrative capability is a separate permission. The primary owner (identified by UUID in the
 * server-side settings file) implicitly holds all of them; nobody else does unless it was granted explicitly.
 */
public enum Permission {
    VIEW_PLAYERS,
    VIEW_STATS,
    EDIT_JOBS,
    EDIT_RANKS,
    MANAGE_STAFF,
    EDIT_BALANCE,
    VIEW_LOGS,
    SERVER_MANAGEMENT;

    public String translationKey() {
        return "permission.marocitytablet." + name().toLowerCase(Locale.ROOT);
    }

    /** Permissions that only the primary owner may hand out or take away (prevents privilege escalation). */
    public boolean ownerOnlyGrant() {
        return this == MANAGE_STAFF || this == SERVER_MANAGEMENT;
    }

    public static Optional<Permission> parse(String s) {
        if (s == null) return Optional.empty();
        try {
            return Optional.of(valueOf(s.trim().toUpperCase(Locale.ROOT)));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
    }
}
