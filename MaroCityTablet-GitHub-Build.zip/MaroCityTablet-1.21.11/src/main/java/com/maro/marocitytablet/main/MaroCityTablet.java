package com.maro.marocitytablet.main;

import com.maro.marocitytablet.networking.ModNetwork;
import com.maro.marocitytablet.registry.ModCreativeTabs;
import com.maro.marocitytablet.registry.ModItems;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.bus.BusGroup;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.RegisterEvent;
import org.slf4j.Logger;

/** Mod entry point. Runs on both the client and the dedicated server; nothing here touches client-only classes. */
@Mod(MaroCityTablet.MOD_ID)
public final class MaroCityTablet {
    public static final String MOD_ID = "marocitytablet";
    public static final Logger LOGGER = LogUtils.getLogger();

    public MaroCityTablet(FMLJavaModLoadingContext context) {
        BusGroup modBus = context.getModBusGroup();

        ModItems.register(modBus);
        RegisterEvent.getBus(modBus).addListener(ModCreativeTabs::onRegister);
        FMLCommonSetupEvent.getBus(modBus).addListener(this::commonSetup);

        ServerEvents.register();
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        ModNetwork.init();
    }
}
