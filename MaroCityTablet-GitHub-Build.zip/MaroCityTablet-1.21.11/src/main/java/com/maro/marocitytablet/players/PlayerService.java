package com.maro.marocitytablet.players;

import com.maro.marocitytablet.admin.OpResult;
import com.maro.marocitytablet.admin.Text;
import com.maro.marocitytablet.config.ServerSettings;
import com.maro.marocitytablet.config.SettingsManager;
import com.maro.marocitytablet.economy.EconomyService;
import com.maro.marocitytablet.storage.DataStore;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.function.LongSupplier;

/** Player profiles: creation on first join, statistics counters, job / rank / level / RP data. */
public final class PlayerService {
    public record LoginResult(PlayerRecord record, boolean created) {}

    private final DataStore store;
    private final SettingsManager settings;
    private final EconomyService economy;
    private final LongSupplier clock;

    public PlayerService(DataStore store, SettingsManager settings, EconomyService economy, LongSupplier clock) {
        this.store = store;
        this.settings = settings;
        this.economy = economy;
        this.clock = clock;
    }

    public LoginResult onLogin(UUID uuid, String name) {
        PlayerRecord r = store.get(uuid);
        boolean created = r == null;
        if (created) {
            r = new PlayerRecord();
            r.uuid = uuid.toString();
            r.name = name;
            r.firstJoin = clock.getAsLong();
            ServerSettings s = settings.get();
            r.job = s.jobs.get(0);
            r.rank = s.ranks.get(0);
            store.put(r);
            economy.grantStarting(r);
        }
        r.name = name;
        r.lastSeen = clock.getAsLong();
        store.markPlayersDirty();
        return new LoginResult(r, created);
    }

    public void onLogout(UUID uuid) {
        PlayerRecord r = store.get(uuid);
        if (r != null) {
            r.lastSeen = clock.getAsLong();
            store.markPlayersDirty();
        }
    }

    // ---- statistics (tracked by the mod from the moment it is installed) ---------------------------------

    public void addPlaySeconds(UUID uuid, int seconds) {
        PlayerRecord r = store.get(uuid);
        if (r != null) {
            r.playSeconds += seconds;
            store.markPlayersDirty();
        }
    }

    public void addDeath(UUID uuid) {
        PlayerRecord r = store.get(uuid);
        if (r != null) {
            r.deaths++;
            store.markPlayersDirty();
        }
    }

    public void addKill(UUID uuid, boolean playerVictim) {
        PlayerRecord r = store.get(uuid);
        if (r != null) {
            if (playerVictim) r.kills++;
            else r.mobKills++;
            store.markPlayersDirty();
        }
    }

    public void addAdvancement(UUID uuid) {
        PlayerRecord r = store.get(uuid);
        if (r != null) {
            r.advancements++;
            store.markPlayersDirty();
        }
    }

    // ---- job / rank / level -------------------------------------------------------------------------------

    public OpResult setJob(PlayerRecord target, String job, String actorName) {
        String canonical = canonical(settings.get().jobs, job);
        if (canonical == null) return OpResult.fail("msg.unknown_job");
        String old = target.job;
        target.job = canonical;
        target.addHistory(new PlayerRecord.HistoryEntry(clock.getAsLong(), "JOB", old, canonical, actorName));
        store.markPlayersDirty();
        return OpResult.ok("msg.job_set", target.name, canonical);
    }

    public OpResult setRank(PlayerRecord target, String rank, String actorName) {
        String canonical = canonical(settings.get().ranks, rank);
        if (canonical == null) return OpResult.fail("msg.unknown_rank");
        String old = target.rank;
        target.rank = canonical;
        target.addHistory(new PlayerRecord.HistoryEntry(clock.getAsLong(), "RANK", old, canonical, actorName));
        store.markPlayersDirty();
        return OpResult.ok("msg.rank_set", target.name, canonical);
    }

    public OpResult setLevel(PlayerRecord target, long level, String actorName) {
        if (level < 1 || level > settings.get().maxLevel) return OpResult.fail("msg.level_invalid", Integer.toString(settings.get().maxLevel));
        int old = target.level;
        target.level = (int) level;
        target.addHistory(new PlayerRecord.HistoryEntry(clock.getAsLong(), "LEVEL", Integer.toString(old), Integer.toString(target.level), actorName));
        store.markPlayersDirty();
        return OpResult.ok("msg.level_set", target.name, Integer.toString(target.level));
    }

    private static String canonical(List<String> allowed, String wanted) {
        if (wanted == null) return null;
        String w = wanted.trim().toLowerCase(Locale.ROOT);
        for (String a : allowed) {
            if (a.toLowerCase(Locale.ROOT).equals(w)) return a;
        }
        return null;
    }

    // ---- roleplay data (edited by the player themself) ----------------------------------------------------

    public OpResult updateRp(PlayerRecord target, String field, String value) {
        if (field == null) return OpResult.fail("msg.rp_invalid");
        switch (field) {
            case "fullName" -> target.rp.fullName = Text.clean(value, 40);
            case "gender" -> target.rp.gender = Text.clean(value, 16);
            case "bio" -> target.rp.bio = Text.clean(value, 200);
            case "age" -> {
                String v = Text.clean(value, 3);
                if (!v.isEmpty()) {
                    if (!v.chars().allMatch(c -> c >= '0' && c <= '9')) return OpResult.fail("msg.rp_invalid");
                    int age = Integer.parseInt(v);
                    if (age < 1 || age > 150) return OpResult.fail("msg.rp_invalid");
                    v = Integer.toString(age);
                }
                target.rp.age = v;
            }
            case "phone" -> {
                String v = Text.clean(value, 20);
                if (!v.chars().allMatch(c -> (c >= '0' && c <= '9') || c == '+' || c == '-' || c == ' ')) return OpResult.fail("msg.rp_invalid");
                target.rp.phone = v;
            }
            default -> {
                return OpResult.fail("msg.rp_invalid");
            }
        }
        store.markPlayersDirty();
        return OpResult.ok("msg.rp_saved");
    }

    // ---- queries ------------------------------------------------------------------------------------------

    /** Matches name, job or rank (case-insensitive substring), sorted by name. An empty query matches everyone. */
    public List<PlayerRecord> search(String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<PlayerRecord> out = new ArrayList<>();
        for (PlayerRecord r : store.players().values()) {
            if (q.isEmpty()
                    || r.name.toLowerCase(Locale.ROOT).contains(q)
                    || r.job.toLowerCase(Locale.ROOT).contains(q)
                    || r.rank.toLowerCase(Locale.ROOT).contains(q)) {
                out.add(r);
            }
        }
        out.sort(Comparator.comparing(r -> r.name.toLowerCase(Locale.ROOT)));
        return out;
    }

    /** Looks up by UUID string first, then by exact name. */
    public PlayerRecord find(String uuidOrName) {
        if (uuidOrName == null || uuidOrName.isBlank()) return null;
        String s = uuidOrName.trim();
        PlayerRecord r = store.get(s);
        return r != null ? r : store.findByName(s);
    }
}
