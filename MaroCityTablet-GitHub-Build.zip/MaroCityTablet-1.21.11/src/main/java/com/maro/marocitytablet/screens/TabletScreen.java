package com.maro.marocitytablet.screens;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.maro.marocitytablet.admin.ActionType;
import com.maro.marocitytablet.client.ClientPacketHandler;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Shared frame of both tablets: dark panel, gold header, sidebar navigation, content area and a toast line.
 * Subclasses provide the tabs and what is drawn / which widgets exist inside the content area.
 * The screen only displays data the server sent and asks the server to do things; it enforces nothing itself.
 */
public abstract class TabletScreen extends Screen {
    protected static final int SIDEBAR = 98;
    protected static final int HEADER = 24;

    public record Tab(String id, String labelKey) {}

    protected JsonObject self;
    protected final Map<String, JsonObject> views = new HashMap<>();
    /** Text typed into edit boxes, kept across widget rebuilds. */
    protected final Map<String, String> fields = new HashMap<>();
    protected String tab;

    protected int px, py, pw, ph; // panel
    protected int cx, cy, cw, ch; // content area

    private String toastText = "";
    private boolean toastOk = true;
    private long toastUntil;

    protected TabletScreen(Component title, JsonObject self, String firstTab) {
        super(title);
        this.self = self;
        this.tab = firstTab;
    }

    // ---- to be provided by the two tablets ------------------------------------------------------------------

    protected abstract List<Tab> tabs();

    protected abstract int sidebarColor();

    protected abstract Component headerTitle();

    /** Adds the widgets of the current tab (called from init). */
    protected abstract void buildContent();

    /** Draws everything of the current tab that is not a widget. Called before the widgets are drawn. */
    protected abstract void renderContent(GuiGraphics g, int mouseX, int mouseY);

    /** Asks the server for the data of the current tab. */
    protected abstract void requestTab();

    /** Called after a view arrived (and before widgets are rebuilt). */
    protected void viewReceived(String name, JsonObject data) {}

    // ---- lifecycle ------------------------------------------------------------------------------------------

    @Override
    protected void init() {
        pw = Math.min(width - 8, 448);
        ph = Math.min(height - 8, 272);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        cx = px + SIDEBAR + 8;
        cy = py + HEADER + 8;
        cw = pw - SIDEBAR - 16;
        ch = ph - HEADER - 16;

        int y = py + HEADER + 6;
        for (Tab t : tabs()) {
            boolean active = t.id().equals(tab);
            Component label = Ui.tr(t.labelKey()).withStyle(active ? ChatFormatting.GOLD : ChatFormatting.WHITE);
            addRenderableWidget(Button.builder(label, b -> switchTab(t.id())).pos(px + 6, y).size(SIDEBAR - 12, 16).build());
            y += 19;
        }
        addRenderableWidget(Button.builder(Ui.tr("ui.close").withStyle(ChatFormatting.RED), b -> onClose())
                .pos(px + 6, py + ph - 22).size(SIDEBAR - 12, 16).build());

        buildContent();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    protected void switchTab(String id) {
        if (id.equals(tab)) return;
        tab = id;
        onTabChanged();
        rebuildWidgets();
        requestTab();
    }

    protected void onTabChanged() {}

    /** Called by the packet handler on the client main thread. */
    public void onView(String name, JsonObject data) {
        switch (name) {
            case "toast" -> {
                JsonArray args = data.has("args") ? data.getAsJsonArray("args") : new JsonArray();
                List<Object> list = new ArrayList<>();
                for (JsonElement e : args) list.add(e.getAsString());
                toastText = Ui.tr(Ui.str(data, "key"), list.toArray()).getString();
                toastOk = Ui.bool(data, "ok");
                toastUntil = System.currentTimeMillis() + 4500;
            }
            case "self" -> self = data;
            default -> views.put(name, data);
        }
        if (!name.equals("toast")) {
            viewReceived(name, data);
            rebuildWidgets();
        }
    }

    // ---- rendering ------------------------------------------------------------------------------------------

    /** The dimmed backdrop is drawn in {@link #render}; vanilla's blurred background is intentionally disabled. */
    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        // intentionally empty
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, width, height, 0xB0000000);

        // panel + gold frame
        Ui.rect(g, px, py, pw, ph, Ui.PANEL);
        Ui.border(g, px - 1, py - 1, pw + 2, ph + 2, Ui.GOLD);

        // sidebar
        Ui.rect(g, px, py, SIDEBAR, ph, sidebarColor());
        Ui.rect(g, px + SIDEBAR - 1, py, 1, ph, Ui.GOLD_DIM);

        // header
        Ui.rect(g, px + SIDEBAR, py, pw - SIDEBAR, HEADER, Ui.BG);
        Ui.rect(g, px + SIDEBAR, py + HEADER - 1, pw - SIDEBAR, 1, Ui.GOLD);
        Ui.text(g, font, headerTitle(), px + SIDEBAR + 8, py + 8, Ui.GOLD);
        String who = Ui.str(self, "name");
        Ui.right(g, font, who, px + pw - 8, py + 8, Ui.MUTED);

        // brand in sidebar header
        Ui.text(g, font, Ui.tr("ui.brand"), px + 8, py + 8, Ui.GOLD);

        renderContent(g, mouseX, mouseY);
        super.render(g, mouseX, mouseY, partialTick);

        if (System.currentTimeMillis() < toastUntil && !toastText.isEmpty()) {
            int w = Math.min(cw, font.width(toastText) + 12);
            int x = cx + (cw - w) / 2;
            int y = py + ph - 20;
            Ui.rect(g, x, y, w, 14, Ui.BG);
            Ui.border(g, x, y, w, 14, toastOk ? Ui.GOOD : Ui.BAD);
            Ui.text(g, font, Ui.fit(font, toastText, w - 8), x + 6, y + 3, toastOk ? Ui.GOOD : Ui.BAD);
        }
    }

    // ---- widget helpers -------------------------------------------------------------------------------------

    protected Button btn(Component label, int x, int y, int w, int h, Runnable action) {
        return addRenderableWidget(Button.builder(label, b -> action.run()).pos(x, y).size(w, h).build());
    }

    protected Button btn(String labelKey, int x, int y, int w, int h, Runnable action) {
        return btn(Ui.tr(labelKey), x, y, w, h, action);
    }

    /** Edit box whose text survives rebuilds via {@link #fields}. */
    protected EditBox edit(String key, int x, int y, int w, int maxLen, String hintKey) {
        EditBox box = new EditBox(font, x, y, w, 16, Component.empty());
        box.setMaxLength(maxLen);
        box.setValue(fields.getOrDefault(key, ""));
        box.setResponder(s -> fields.put(key, s));
        if (hintKey != null) box.setHint(Ui.tr(hintKey));
        return addRenderableWidget(box);
    }

    protected String field(String key) {
        return fields.getOrDefault(key, "").trim();
    }

    protected void send(ActionType type, String target, String a, String b, long n) {
        ClientPacketHandler.send(type, target, a, b, n);
    }

    protected static long parseLong(String s) {
        try {
            return Long.parseLong(s.trim().replace(",", ""));
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    protected boolean hasPerm(String perm) {
        if (self == null || !self.has("perms")) return false;
        for (JsonElement e : self.getAsJsonArray("perms")) {
            if (e.getAsString().equals(perm)) return true;
        }
        return false;
    }

    protected String currency() {
        String c = Ui.str(self, "currency");
        return c.isEmpty() ? "$" : c;
    }

    // ---- shared drawing -------------------------------------------------------------------------------------

    protected void statCard(GuiGraphics g, int x, int y, int w, int h, String label, String value, int valueColor) {
        Ui.card(g, x, y, w, h);
        Ui.text(g, font, Ui.fit(font, label, w - 10), x + 6, y + 5, Ui.MUTED);
        Ui.text(g, font, Ui.fit(font, value, w - 10), x + 6, y + 17, valueColor);
    }

    protected void avatar(GuiGraphics g, int x, int y, int size, String name) {
        Ui.rect(g, x, y, size, size, Ui.RED_DARK);
        Ui.border(g, x, y, size, size, Ui.GOLD);
        String initial = name == null || name.isEmpty() ? "?" : new String(Character.toChars(name.codePointAt(0))).toUpperCase();
        Ui.centered(g, font, initial, x + size / 2, y + size / 2 - 4, Ui.GOLD);
    }
}
