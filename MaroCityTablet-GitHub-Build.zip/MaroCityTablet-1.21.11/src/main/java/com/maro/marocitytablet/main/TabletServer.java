package com.maro.marocitytablet.main;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.maro.marocitytablet.admin.ActionService;
import com.maro.marocitytablet.admin.ActionType;
import com.maro.marocitytablet.admin.OnlineInfo;
import com.maro.marocitytablet.admin.TabletCore;
import com.maro.marocitytablet.items.TabletKind;
import com.maro.marocitytablet.networking.ActionPacket;
import com.maro.marocitytablet.networking.ModNetwork;
import com.maro.marocitytablet.networking.OpenTabletPacket;
import com.maro.marocitytablet.networking.RateLimiter;
import com.maro.marocitytablet.networking.ViewPacket;
import com.maro.marocitytablet.players.PlayerRecord;
import com.maro.marocitytablet.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.network.PacketDistributor;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Server-side glue between Minecraft and the pure-Java {@link TabletCore}. All state lives in {@code core};
 * everything that arrives from a client is routed through {@link TabletCore#actions}.
 */
public final class TabletServer {
    private static TabletCore core;
    private static MinecraftServer server;
    private static final RateLimiter LIMITER = new RateLimiter(40, 1000L);

    private TabletServer() {}

    public static TabletCore core() {
        return core;
    }

    public static MinecraftServer server() {
        return server;
    }

    // ---- lifecycle ----------------------------------------------------------------------------------------

    static void start(MinecraftServer s) {
        server = s;
        Path settingsFile = FMLPaths.CONFIGDIR.get().resolve("marocitytablet-server.json");
        Path dataDir = s.getWorldPath(LevelResource.ROOT).resolve("marocitytablet");
        OnlineInfo online = new OnlineInfo() {
            @Override
            public boolean isOnline(UUID uuid) {
                MinecraftServer cur = server;
                return cur != null && cur.getPlayerList().getPlayer(uuid) != null;
            }

            @Override
            public int onlineCount() {
                MinecraftServer cur = server;
                return cur == null ? 0 : cur.getPlayerList().getPlayerCount();
            }
        };
        core = new TabletCore(settingsFile, dataDir, System::currentTimeMillis, online);
        core.load();
        MaroCityTablet.LOGGER.info("MaroCityTablet loaded {} player profiles from {}", core.store.players().size(), dataDir);
    }

    static void save() {
        if (core != null) core.saveAll();
    }

    static void stop() {
        save();
        core = null;
        server = null;
    }

    // ---- player events ------------------------------------------------------------------------------------

    static void onLogin(ServerPlayer player) {
        if (core == null) return;
        var result = core.players.onLogin(player.getUUID(), nameOf(player));
        if (result.created() && core.settings.get().giveTabletOnFirstJoin) {
            giveTablet(player, ModItems.PLAYER_TABLET.get());
        }
    }

    static void onLogout(ServerPlayer player) {
        if (core == null) return;
        core.players.onLogout(player.getUUID());
        LIMITER.forget(player.getUUID());
        core.store.saveIfDirty();
    }

    public static String nameOf(ServerPlayer p) {
        return p.getName().getString();
    }

    public static void giveTablet(ServerPlayer player, Item item) {
        ItemStack stack = new ItemStack(item);
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
    }

    public static boolean hasItem(ServerPlayer player, Item item) {
        var inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).getItem() == item) return true;
        }
        return false;
    }

    // ---- tablet use / packets ----------------------------------------------------------------------------

    /** Called when a player right-clicks a tablet. The server decides; the client only ever receives the result. */
    public static void openTablet(ServerPlayer player, TabletKind kind) {
        if (core == null) return;
        UUID id = player.getUUID();
        PlayerRecord rec = core.store.get(id);
        if (rec == null) rec = core.players.onLogin(id, nameOf(player)).record();
        if (kind == TabletKind.OWNER && !core.permissions.isAdmin(id)) {
            player.sendSystemMessage(Component.translatable("marocitytablet.msg.no_access"));
            return;
        }
        JsonObject self = core.views.self(rec);
        ModNetwork.CHANNEL.send(new OpenTabletPacket(kind, self.toString()), PacketDistributor.PLAYER.with(player));
    }

    /** Entry point for every client request. Runs on the server thread. */
    public static void handleAction(ServerPlayer player, ActionPacket packet) {
        if (core == null || packet.action() == ActionType.INVALID) return;
        if (!LIMITER.allow(player.getUUID(), System.currentTimeMillis())) return; // flood protection: drop silently
        runAction(player, packet.action(), packet.target(), packet.a(), packet.b(), packet.n(), false);
    }

    /** Shared by the packet handler and the chat commands. */
    public static void runAction(ServerPlayer player, ActionType type, String target, String a, String b, long n, boolean chatFeedback) {
        if (core == null) return;
        ActionService.Response response = core.actions.handle(player.getUUID(), nameOf(player), type, target, a, b, n);
        for (ActionService.View view : response.views()) {
            send(player, view.name(), view.data());
            if (chatFeedback && view.name().equals("toast")) {
                player.sendSystemMessage(toastComponent(view.data()));
            }
        }
        for (ActionService.Notice notice : response.notices()) {
            MinecraftServer s = server;
            if (s == null) continue;
            ServerPlayer other = s.getPlayerList().getPlayer(notice.target());
            if (other != null) {
                other.sendSystemMessage(Component.translatable("marocitytablet." + notice.key(), notice.args().toArray()));
                PlayerRecord rec = core.store.get(other.getUUID());
                if (rec != null) send(other, "self", core.views.self(rec));
            }
        }
    }

    public static void send(ServerPlayer player, String view, JsonObject data) {
        try {
            ModNetwork.CHANNEL.send(new ViewPacket(view, data.toString()), PacketDistributor.PLAYER.with(player));
        } catch (RuntimeException e) {
            MaroCityTablet.LOGGER.error("Could not send view {} to {}", view, nameOf(player), e);
        }
    }

    public static Component toastComponent(JsonObject toast) {
        String key = toast.get("key").getAsString();
        List<Object> args = new ArrayList<>();
        JsonArray arr = toast.getAsJsonArray("args");
        for (JsonElement e : arr) args.add(e.getAsString());
        return Component.translatable("marocitytablet." + key, args.toArray());
    }
}
