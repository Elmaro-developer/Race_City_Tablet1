package com.maro.marocitytablet.main;

import com.maro.marocitytablet.admin.TabletCore;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.AdvancementEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;

/** Subscriptions on the main Forge event buses (server side only logic). */
public final class ServerEvents {
    private ServerEvents() {}

    public static void register() {
        ServerStartingEvent.BUS.addListener(ServerEvents::onStarting);
        ServerStoppingEvent.BUS.addListener(ServerEvents::onStopping);
        ServerStoppedEvent.BUS.addListener(ServerEvents::onStopped);
        TickEvent.ServerTickEvent.Post.BUS.addListener(ServerEvents::onServerTick);
        PlayerEvent.PlayerLoggedInEvent.BUS.addListener(ServerEvents::onLogin);
        PlayerEvent.PlayerLoggedOutEvent.BUS.addListener(ServerEvents::onLogout);
        LivingDeathEvent.BUS.addListener(ServerEvents::onDeath);
        AdvancementEvent.AdvancementEarnEvent.BUS.addListener(ServerEvents::onAdvancement);
        RegisterCommandsEvent.BUS.addListener(TabletCommands::register);
    }

    private static void onStarting(ServerStartingEvent event) {
        TabletServer.start(event.getServer());
    }

    private static void onStopping(ServerStoppingEvent event) {
        TabletServer.save();
    }

    private static void onStopped(ServerStoppedEvent event) {
        TabletServer.stop();
    }

    private static void onServerTick(TickEvent.ServerTickEvent.Post event) {
        TabletCore core = TabletServer.core();
        if (core == null) return;
        MinecraftServer server = event.server();
        int tick = server.getTickCount();
        if (tick % 20 == 0) {
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                core.players.addPlaySeconds(p.getUUID(), 1);
            }
        }
        if (tick % 600 == 0) {
            core.store.saveIfDirty(); // every 30 seconds
        }
    }

    private static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) TabletServer.onLogin(p);
    }

    private static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) TabletServer.onLogout(p);
    }

    private static void onDeath(LivingDeathEvent event) {
        TabletCore core = TabletServer.core();
        if (core == null) return;
        LivingEntity victim = event.getEntity();
        DamageSource source = event.getSource();
        if (victim instanceof ServerPlayer dead) {
            core.players.addDeath(dead.getUUID());
            if (source.getEntity() instanceof ServerPlayer killer && killer != dead) {
                core.players.addKill(killer.getUUID(), true);
            }
        } else if (source.getEntity() instanceof ServerPlayer killer) {
            core.players.addKill(killer.getUUID(), false);
        }
    }

    private static void onAdvancement(AdvancementEvent.AdvancementEarnEvent event) {
        TabletCore core = TabletServer.core();
        if (core == null) return;
        // Count only advancements that are visible in the advancement screen, not recipe unlocks.
        if (event.getEntity() instanceof ServerPlayer p && event.getAdvancement().value().display().isPresent()) {
            core.players.addAdvancement(p.getUUID());
        }
    }
}
