package com.maro.marocitytablet.screens;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.maro.marocitytablet.admin.ActionType;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * The citizen tablet: profile, wallet (with transfers), roleplay data and job / rank history.
 * Black + gold theme. Everything shown here belongs to the viewer only.
 */
public class PlayerTabletScreen extends TabletScreen {
    private static final List<Tab> TABS = List.of(
            new Tab("profile", "tab.profile"),
            new Tab("wallet", "tab.wallet"),
            new Tab("rp", "tab.rp"),
            new Tab("history", "tab.history"));

    private static final int HISTORY_ROWS = 10;

    private int txPage;
    private int historyPage;

    public PlayerTabletScreen(JsonObject self) {
        super(Ui.tr("player_tablet.title"), self, "profile");
        fields.put("rp.fullName", Ui.str(Ui.obj(self, "rp"), "fullName"));
        fields.put("rp.age", Ui.str(Ui.obj(self, "rp"), "age"));
        fields.put("rp.gender", Ui.str(Ui.obj(self, "rp"), "gender"));
        fields.put("rp.phone", Ui.str(Ui.obj(self, "rp"), "phone"));
        fields.put("rp.bio", Ui.str(Ui.obj(self, "rp"), "bio"));
    }

    @Override
    protected List<Tab> tabs() {
        return TABS;
    }

    @Override
    protected int sidebarColor() {
        return Ui.SIDEBAR_PLAYER;
    }

    @Override
    protected Component headerTitle() {
        return Ui.tr("tab." + tab);
    }

    @Override
    protected void requestTab() {
        switch (tab) {
            case "profile" -> send(ActionType.SELF, "", "", "", 0);
            case "wallet" -> send(ActionType.MY_TX, "", "", "", txPage);
            default -> { }
        }
    }

    @Override
    protected void init() {
        super.init();
        if (!views.containsKey("tx") && tab.equals("wallet")) requestTab();
    }

    // ---- widgets ---------------------------------------------------------------------------------------------

    @Override
    protected void buildContent() {
        switch (tab) {
            case "wallet" -> buildWallet();
            case "rp" -> buildRp();
            case "history" -> buildHistory();
            default -> { }
        }
    }

    private void buildWallet() {
        if (Ui.bool(self, "allowTransfers")) {
            int half = (cw - 4) / 2;
            edit("tx.to", cx, cy + 34, half, 16, "wallet.player_hint");
            edit("tx.amount", cx + half + 4, cy + 34, half, 12, "wallet.amount_hint");
            edit("tx.note", cx, cy + 54, cw - 64, 60, "wallet.note_hint");
            btn("wallet.send", cx + cw - 60, cy + 54, 60, 16, () -> {
                long amount = parseLong(field("tx.amount"));
                if (amount <= 0) {
                    onView("toast", toastJson("msg.amount_invalid"));
                    return;
                }
                send(ActionType.TRANSFER, "", field("tx.to"), field("tx.note"), amount);
                fields.put("tx.amount", "");
                fields.put("tx.note", "");
            });
        }
        int pagerY = cy + ch - 18;
        JsonObject tx = views.get("tx");
        int pages = tx == null ? 1 : (int) Math.max(1, Ui.num(tx, "pages"));
        btn(Component.literal("<"), cx, pagerY, 20, 14, () -> {
            if (txPage > 0) {
                txPage--;
                requestTab();
            }
        });
        btn(Component.literal(">"), cx + 24, pagerY, 20, 14, () -> {
            if (txPage + 1 < pages) {
                txPage++;
                requestTab();
            }
        });
    }

    private void buildRp() {
        int half = (cw - 4) / 2;
        int y = cy + 12;
        edit("rp.fullName", cx, y, half, 40, null);
        edit("rp.age", cx + half + 4, y, half, 3, null);
        edit("rp.gender", cx, y + 32, half, 16, null);
        edit("rp.phone", cx + half + 4, y + 32, half, 20, null);
        edit("rp.bio", cx, y + 64, cw, 200, null);
        btn("rp.save", cx, y + 90, 90, 16, () -> {
            for (String f : new String[]{"fullName", "age", "gender", "phone", "bio"}) {
                send(ActionType.RP_UPDATE, "", f, field("rp." + f), 0);
            }
        });
    }

    private void buildHistory() {
        int pagerY = cy + ch - 18;
        int pages = Math.max(1, (historySize() + HISTORY_ROWS - 1) / HISTORY_ROWS);
        btn(Component.literal("<"), cx, pagerY, 20, 14, () -> {
            if (historyPage > 0) {
                historyPage--;
                rebuildWidgets();
            }
        });
        btn(Component.literal(">"), cx + 24, pagerY, 20, 14, () -> {
            if (historyPage + 1 < pages) {
                historyPage++;
                rebuildWidgets();
            }
        });
    }

    private int historySize() {
        return self.has("history") ? self.getAsJsonArray("history").size() : 0;
    }

    private JsonObject toastJson(String key) {
        JsonObject o = new JsonObject();
        o.addProperty("ok", false);
        o.addProperty("key", key);
        o.add("args", new JsonArray());
        return o;
    }

    // ---- drawing -----------------------------------------------------------------------------------------------

    @Override
    protected void renderContent(GuiGraphics g, int mouseX, int mouseY) {
        switch (tab) {
            case "wallet" -> renderWallet(g);
            case "rp" -> renderRp(g);
            case "history" -> renderHistory(g);
            default -> renderProfile(g);
        }
    }

    private void renderProfile(GuiGraphics g) {
        String name = Ui.str(self, "name");
        JsonObject rp = Ui.obj(self, "rp");
        avatar(g, cx, cy, 40, name);
        Ui.text(g, font, name, cx + 48, cy + 2, Ui.GOLD);
        String rpName = Ui.str(rp, "fullName");
        Ui.text(g, font, rpName.isEmpty() ? Ui.tr("profile.no_rp_name").getString() : rpName, cx + 48, cy + 13, Ui.MUTED);
        Ui.text(g, font, Ui.str(self, "job") + "  |  " + Ui.str(self, "rank"), cx + 48, cy + 24, Ui.TEXT);

        long level = Ui.num(self, "level");
        long max = Math.max(1, Ui.num(self, "maxLevel"));
        int barX = cx + 48, barW = cw - 48;
        Ui.rect(g, barX, cy + 36, barW, 5, Ui.PANEL_2);
        Ui.rect(g, barX, cy + 36, (int) (barW * Math.min(1.0, level / (double) max)), 5, Ui.RED);
        Ui.border(g, barX, cy + 36, barW, 5, Ui.GOLD_DIM);

        int gap = 6;
        int w = (cw - gap * 2) / 3;
        int h = 34;
        int y0 = cy + 50;
        String[][] cards = {
                {"card.balance", Ui.money(Ui.num(self, "balance"), currency())},
                {"card.playtime", Ui.duration(Ui.num(self, "playSeconds"))},
                {"card.level", level + " / " + max},
                {"card.kills", Ui.number(Ui.num(self, "kills"))},
                {"card.mob_kills", Ui.number(Ui.num(self, "mobKills"))},
                {"card.deaths", Ui.number(Ui.num(self, "deaths"))},
                {"card.advancements", Ui.number(Ui.num(self, "advancements"))},
                {"card.member_since", Ui.date(Ui.num(self, "firstJoin")).substring(0, Math.min(10, Ui.date(Ui.num(self, "firstJoin")).length()))},
                {"card.city", Ui.str(self, "cityName")},
        };
        for (int i = 0; i < cards.length; i++) {
            int x = cx + (i % 3) * (w + gap);
            int y = y0 + (i / 3) * (h + gap);
            statCard(g, x, y, w, h, Ui.tr(cards[i][0]).getString(), cards[i][1], i == 0 ? Ui.GOLD : Ui.TEXT);
        }
        Ui.text(g, font, Ui.tr("profile.stats_note"), cx, cy + ch - 10, Ui.MUTED);
    }

    private void renderWallet(GuiGraphics g) {
        Ui.card(g, cx, cy, cw, 26);
        Ui.text(g, font, Ui.tr("wallet.balance"), cx + 8, cy + 4, Ui.MUTED);
        Ui.text(g, font, Ui.money(Ui.num(self, "balance"), currency()), cx + 8, cy + 14, Ui.GOLD);

        if (Ui.bool(self, "allowTransfers")) {
            Ui.text(g, font, Ui.tr("wallet.send_title"), cx, cy + 28 - 0, Ui.MUTED);
        } else {
            Ui.text(g, font, Ui.tr("msg.transfers_disabled"), cx, cy + 34, Ui.BAD);
        }

        int ty = cy + 76;
        Ui.text(g, font, Ui.tr("wallet.recent"), cx, ty, Ui.GOLD);
        Ui.rect(g, cx, ty + 10, cw, 1, Ui.GOLD_DIM);

        JsonObject tx = views.get("tx");
        if (tx == null) {
            Ui.text(g, font, Ui.tr("ui.loading"), cx, ty + 16, Ui.MUTED);
            return;
        }
        JsonArray entries = tx.getAsJsonArray("entries");
        if (entries.isEmpty()) {
            Ui.text(g, font, Ui.tr("wallet.none"), cx, ty + 16, Ui.MUTED);
        }
        int y = ty + 14;
        for (JsonElement el : entries) {
            JsonObject e = el.getAsJsonObject();
            boolean incoming = Ui.bool(e, "incoming");
            String sign = incoming ? "+" : "-";
            String who = incoming ? Ui.str(e, "from") : Ui.str(e, "to");
            if (who.isEmpty()) who = Ui.str(e, "type");
            String note = Ui.str(e, "note");
            Ui.sequence(g, font, cx, y, cx + cw,
                    Ui.dateShort(Ui.num(e, "time")) + "  ", Ui.MUTED,
                    sign + Ui.number(Ui.num(e, "amount")) + " " + currency() + "  ", incoming ? Ui.GOOD : Ui.BAD,
                    who, Ui.TEXT,
                    note.isEmpty() ? "" : "  - " + note, Ui.MUTED);
            y += 10;
        }
        Ui.text(g, font, (Ui.num(tx, "page") + 1) + " / " + Ui.num(tx, "pages"), cx + 50, cy + ch - 15, Ui.MUTED);
    }

    private void renderRp(GuiGraphics g) {
        int half = (cw - 4) / 2;
        int y = cy + 12;
        Ui.text(g, font, Ui.tr("rp.full_name"), cx, y - 10, Ui.GOLD);
        Ui.text(g, font, Ui.tr("rp.age"), cx + half + 4, y - 10, Ui.GOLD);
        Ui.text(g, font, Ui.tr("rp.gender"), cx, y + 22, Ui.GOLD);
        Ui.text(g, font, Ui.tr("rp.phone"), cx + half + 4, y + 22, Ui.GOLD);
        Ui.text(g, font, Ui.tr("rp.bio"), cx, y + 54, Ui.GOLD);
        Ui.text(g, font, Ui.tr("rp.note"), cx, y + 112, Ui.MUTED);
    }

    private void renderHistory(GuiGraphics g) {
        JsonArray hist = self.has("history") ? self.getAsJsonArray("history") : new JsonArray();
        Ui.text(g, font, Ui.tr("history.title"), cx, cy, Ui.GOLD);
        Ui.rect(g, cx, cy + 10, cw, 1, Ui.GOLD_DIM);
        if (hist.isEmpty()) {
            Ui.text(g, font, Ui.tr("history.none"), cx, cy + 18, Ui.MUTED);
            return;
        }
        int y = cy + 16;
        int pages = Math.max(1, (hist.size() + HISTORY_ROWS - 1) / HISTORY_ROWS);
        int page = Math.min(historyPage, pages - 1);
        for (int i = page * HISTORY_ROWS; i < Math.min(hist.size(), (page + 1) * HISTORY_ROWS); i++) {
            JsonObject e = hist.get(i).getAsJsonObject();
            String type = Ui.tr("history.type." + Ui.str(e, "type").toLowerCase()).getString();
            Ui.sequence(g, font, cx, y, cx + cw,
                    Ui.dateShort(Ui.num(e, "time")) + "  ", Ui.MUTED,
                    type + ": ", Ui.GOLD,
                    Ui.str(e, "from") + " > " + Ui.str(e, "to"), Ui.TEXT,
                    "   " + Ui.str(e, "by"), Ui.MUTED);
            y += 12;
        }
        Ui.text(g, font, (page + 1) + " / " + pages, cx + 50, cy + ch - 15, Ui.MUTED);
    }
}
