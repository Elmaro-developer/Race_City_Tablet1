package com.maro.marocitytablet.admin;

/** One row of the administrative audit log (successful actions and denied attempts). */
public final class AdminLogEntry {
    public long id;
    public long time;
    public String actorUuid;
    public String actorName;
    /** E.g. SET_JOB, BAL_ADD, STAFF_ADD, or DENIED:SET_JOB. */
    public String action;
    public String targetUuid;
    public String targetName;
    public String details;
}
