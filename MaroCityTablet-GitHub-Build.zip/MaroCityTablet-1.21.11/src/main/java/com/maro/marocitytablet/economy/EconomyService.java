package com.maro.marocitytablet.economy;

import com.maro.marocitytablet.admin.OpResult;
import com.maro.marocitytablet.admin.Text;
import com.maro.marocitytablet.config.ServerSettings;
import com.maro.marocitytablet.config.SettingsManager;
import com.maro.marocitytablet.players.PlayerRecord;
import com.maro.marocitytablet.storage.DataStore;

import java.util.function.LongSupplier;

/**
 * Internal currency. Invariants: balances are never negative, never above {@code maxBalance}, and every change
 * is written to the ledger. Because {@code maxBalance <= 1e15}, the sum of two balances cannot overflow a long.
 */
public final class EconomyService {
    public enum Mode { ADD, REMOVE, SET }

    private final DataStore store;
    private final SettingsManager settings;
    private final LongSupplier clock;

    public EconomyService(DataStore store, SettingsManager settings, LongSupplier clock) {
        this.store = store;
        this.settings = settings;
        this.clock = clock;
    }

    /** Administrative change (add / remove / set). */
    public OpResult adjust(PlayerRecord target, Mode mode, long amount, String actorUuid, String actorName, String reason) {
        ServerSettings s = settings.get();
        if (mode == Mode.SET ? (amount < 0 || amount > s.maxBalance) : (amount <= 0 || amount > s.maxBalance)) {
            return OpResult.fail("msg.amount_invalid");
        }
        long before = target.balance;
        long after;
        switch (mode) {
            case ADD -> {
                after = before + amount;
                if (after > s.maxBalance) return OpResult.fail("msg.balance_too_high");
            }
            case REMOVE -> {
                if (before < amount) return OpResult.fail("msg.insufficient_funds");
                after = before - amount;
            }
            default -> after = amount;
        }
        target.balance = after;
        store.markPlayersDirty();

        Transaction t = base(mode.name(), amount, Text.clean(reason, 80));
        t.toUuid = target.uuid;
        t.toName = target.name;
        t.balanceAfter = after;
        t.actorUuid = actorUuid;
        t.actorName = actorName;
        store.addTransaction(t);
        return OpResult.ok("msg.balance_updated", target.name, Long.toString(after));
    }

    /** Player to player transfer. Atomic: either both balances change and one ledger row is written, or nothing. */
    public OpResult transfer(PlayerRecord from, PlayerRecord to, long amount, String note) {
        ServerSettings s = settings.get();
        if (!s.allowTransfers) return OpResult.fail("msg.transfers_disabled");
        if (from.uuid.equals(to.uuid)) return OpResult.fail("msg.cannot_pay_self");
        if (amount <= 0 || amount > s.maxBalance) return OpResult.fail("msg.amount_invalid");
        if (from.balance < amount) return OpResult.fail("msg.insufficient_funds");
        if (to.balance + amount > s.maxBalance) return OpResult.fail("msg.recipient_balance_too_high");

        from.balance -= amount;
        to.balance += amount;
        store.markPlayersDirty();

        Transaction t = base("TRANSFER", amount, Text.clean(note, 80));
        t.fromUuid = from.uuid;
        t.fromName = from.name;
        t.toUuid = to.uuid;
        t.toName = to.name;
        t.balanceAfter = to.balance;
        t.actorUuid = from.uuid;
        t.actorName = from.name;
        store.addTransaction(t);
        return OpResult.ok("msg.transfer_done", Long.toString(amount), to.name);
    }

    /** Starting balance for a brand-new player. Logged as STARTING. */
    public void grantStarting(PlayerRecord r) {
        long amount = Math.min(settings.get().startingBalance, settings.get().maxBalance);
        r.balance = amount;
        store.markPlayersDirty();
        if (amount > 0) {
            Transaction t = base("STARTING", amount, "");
            t.toUuid = r.uuid;
            t.toName = r.name;
            t.balanceAfter = amount;
            t.actorName = "system";
            store.addTransaction(t);
        }
    }

    private Transaction base(String type, long amount, String reason) {
        Transaction t = new Transaction();
        t.id = store.nextTransactionId();
        t.time = clock.getAsLong();
        t.type = type;
        t.amount = amount;
        t.reason = reason;
        return t;
    }
}
