package com.maro.marocitytablet.items;

import com.maro.marocitytablet.main.TabletServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/**
 * Both tablets are the same item class with a different {@link TabletKind}. Holding an Owner Tablet grants nothing:
 * on right click the SERVER decides whether the user may open it, and it only ever sends data the user is allowed
 * to see. No owner information exists on the client.
 */
public class TabletItem extends Item {
    private final TabletKind kind;

    public TabletItem(Properties properties, TabletKind kind) {
        super(properties);
        this.kind = kind;
    }

    public TabletKind kind() {
        return kind;
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (player instanceof ServerPlayer serverPlayer) {
            TabletServer.openTablet(serverPlayer, kind);
        }
        return InteractionResult.SUCCESS;
    }
}
